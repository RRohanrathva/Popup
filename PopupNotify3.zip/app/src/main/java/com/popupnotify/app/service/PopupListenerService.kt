package com.popupnotify.app.service

import android.app.Notification
import android.content.ComponentName
import android.util.Log
import android.graphics.drawable.Drawable
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.popupnotify.app.SettingsStore
import com.popupnotify.app.overlay.OverlayManager
import com.popupnotify.app.overlay.PopupAction
import com.popupnotify.app.overlay.PopupData

class PopupListenerService : NotificationListenerService() {

    private lateinit var overlay: OverlayManager
    private lateinit var settings: SettingsStore
    private val history = HashMap<String, ArrayDeque<String>>()

    override fun onCreate() {
        super.onCreate()
        overlay = OverlayManager(applicationContext)
        settings = SettingsStore.get(applicationContext)
    }

    override fun onDestroy() {
        overlay.destroy()
        super.onDestroy()
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.d(TAG, "listener connected")
    }

    /** The system (or HyperOS battery saver) dropped us: ask to be bound again. */
    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        Log.d(TAG, "listener disconnected, rebinding")
        try { requestRebind(ComponentName(this, PopupListenerService::class.java)) } catch (_: Exception) {}
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            handle(sbn)
        } catch (t: Throwable) {
            // Never let one odd notification kill the listener.
            Log.e(TAG, "popup failed for ${sbn.packageName}", t)
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        if (!settings.popupEnabled.value) return
        if (sbn.packageName == packageName) return
        if (sbn.packageName in settings.blocked) return

        val n = sbn.notification
        val flags = n.flags
        if (flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (flags and Notification.FLAG_FOREGROUND_SERVICE != 0) return
        if (settings.ignoreOngoing.value && flags and Notification.FLAG_ONGOING_EVENT != 0 &&
            n.category != Notification.CATEGORY_CALL
        ) return

        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val isCall = n.category == Notification.CATEGORY_CALL && n.fullScreenIntent != null ||
            (n.category == Notification.CATEGORY_CALL && isIncomingCall(n))
        if (isCall && !settings.callEnabled.value) return

        val appIcon: Drawable? = try { packageManager.getApplicationIcon(sbn.packageName) } catch (_: Exception) { null }
        val appName = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) { sbn.packageName }
        val large: Drawable? = try { n.getLargeIcon()?.loadDrawable(this) } catch (_: Exception) { null }

        var answer: android.app.PendingIntent? = null
        var decline: android.app.PendingIntent? = null
        if (isCall) {
            n.actions?.forEach { a ->
                val t = a.title?.toString()?.lowercase().orEmpty()
                if (answer == null && (t.contains("answer") || t.contains("accept") || t.contains("pick") || t.contains("उत्तर"))) answer = a.actionIntent
                if (decline == null && (t.contains("decline") || t.contains("reject") || t.contains("hang") || t.contains("end") || t.contains("dismiss"))) decline = a.actionIntent
            }
            if (answer == null && n.actions?.size == 2) {
                decline = n.actions[0].actionIntent
                answer = n.actions[1].actionIntent
            }
        }

        val actions = (n.actions ?: emptyArray()).mapNotNull { a ->
            val label = a.title?.toString() ?: return@mapNotNull null
            if (a.actionIntent == null) return@mapNotNull null
            val ri = a.remoteInputs
            val reply = ri != null && ri.any { it.allowFreeFormInput }
            val choices = ri?.flatMap { r -> r.choices?.map { c -> c.toString() } ?: emptyList() } ?: emptyList()
            PopupAction(label, a.actionIntent, ri, choices, reply)
        }

        val line = if (title.isBlank()) text else if (text.isBlank()) title else "$title: $text"
        currentKey = sbn.key
        val earlier = collectEarlier(sbn.packageName, n, line)

        overlay.show(
            PopupData(
                actions = actions,
                history = earlier,
                key = sbn.key,
                pkg = sbn.packageName,
                appName = appName,
                title = title,
                text = text,
                appIcon = appIcon,
                largeIcon = large,
                contentIntent = n.contentIntent,
                isCall = isCall,
                answer = answer,
                decline = decline,
            ),
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        overlay.dismissKey(sbn.key)
    }

    /** Earlier messages of the same app: from the app's own conversation if it has one, else what we saw before. */
    private var currentKey: String? = null

    private fun collectEarlier(pkg: String, n: Notification, line: String): List<String> {
        var fromApp: List<String> = emptyList()
        try {
            val arr = n.extras.getParcelableArray(Notification.EXTRA_MESSAGES)
            if (arr != null && arr.size > 1) {
                val msgs = Notification.MessagingStyle.Message.getMessagesFromBundleArray(arr)
                fromApp = msgs.dropLast(1).takeLast(3).mapNotNull { m ->
                    val t = m.text?.toString() ?: return@mapNotNull null
                    val who = m.sender?.toString()
                    if (who.isNullOrBlank()) t else "$who: $t"
                }
            }
        } catch (_: Exception) {
        }
        if (fromApp.isEmpty()) {
            // Other notifications of the same app that are still in the shade.
            try {
                fromApp = activeNotifications
                    .filter { it.packageName == pkg && it.notification !== n && it.key != currentKey }
                    .filter { it.notification.flags and Notification.FLAG_GROUP_SUMMARY == 0 }
                    .sortedBy { it.postTime }
                    .mapNotNull { o ->
                        val e = o.notification.extras
                        val t = e.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
                        val x = (e.getCharSequence(Notification.EXTRA_TEXT) ?: e.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString().orEmpty()
                        val l = if (t.isBlank()) x else if (x.isBlank()) t else "$t: $x"
                        l.ifBlank { null }
                    }
                    .filter { it != line }
                    .takeLast(3)
            } catch (_: Exception) {
            }
        }
        val q = history.getOrPut(pkg) { ArrayDeque() }
        val seen = q.toList()
        if (q.lastOrNull() != line) {
            q.addLast(line)
            while (q.size > 4) q.removeFirst()
        }
        val before = if (seen.lastOrNull() == line) seen.dropLast(1) else seen
        return if (fromApp.isNotEmpty()) fromApp else before.takeLast(3)
    }

    private fun isIncomingCall(n: Notification): Boolean = (n.actions?.size ?: 0) >= 2

    private companion object { const val TAG = "PopupNotify" }
}
