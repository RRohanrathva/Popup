package com.expressive.popupnotify

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.expressive.popupnotify.ui.ExpressivePopupTheme
import com.expressive.popupnotify.ui.PopupConfig
import com.expressive.popupnotify.ui.SettingsScreen

class MainActivity : ComponentActivity() {

    companion object {
        var currentConfig by mutableStateOf(PopupConfig())
        var callPopupEnabled by mutableStateOf(true)
    }

    private var hasOverlay by mutableStateOf(false)
    private var hasNotifyAccess by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val perms = mutableListOf(Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        requestPermissions(perms.toTypedArray(), 101)
        refreshPermissionStates()

        setContent {
            ExpressivePopupTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    SettingsScreen(
                        config = currentConfig,
                        callPopupEnabled = callPopupEnabled,
                        hasOverlayPermission = hasOverlay,
                        hasNotificationAccess = hasNotifyAccess,
                        onConfigChange = { currentConfig = it },
                        onCallPopupToggle = { callPopupEnabled = it },
                        onRequestOverlayPermission = {
                            startActivity(
                                Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:$packageName")
                                )
                            )
                        },
                        onRequestNotificationAccess = {
                            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        },
                        onTestNotificationPopup = {
                            OverlayManager.showPopup(
                                context = this,
                                appName = "WhatsApp",
                                title = "PixelOS Expressive Popup",
                                message = "Swipe UP to dismiss • Swipe DOWN bottom bar for Floating Window!",
                                config = currentConfig.copy(isCallPopup = false),
                                targetPackage = "com.whatsapp"
                            )
                        },
                        onTestCallPopup = {
                            OverlayManager.showPopup(
                                context = this,
                                appName = "Phone",
                                title = "+91 93270 58967",
                                message = "Mobile • Incoming Call",
                                config = currentConfig.copy(isCallPopup = true),
                                targetPackage = "com.android.incallui"
                            )
                        }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionStates()
    }

    private fun refreshPermissionStates() {
        hasOverlay = Settings.canDrawOverlays(this)
        val enabledListeners = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        val myComponent = ComponentName(this, NotificationListenerService::class.java).flattenToString()
        hasNotifyAccess = enabledListeners.contains(myComponent) || enabledListeners.contains(packageName)
    }
}
