package com.expressive.popupnotify.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

// PixelOS / Android 17 Material 3 Expressive Tonal Surfaces
val PixelDarkSurface = Color(0xFF0E0E12)
val PixelDarkContainer = Color(0xFF1E1E26)
val PixelDarkContainerHigh = Color(0xFF282832)
val PixelDarkPrimary = Color(0xFFD0BCFF)
val PixelDarkPrimaryContainer = Color(0xFF4F378B)
val PixelDarkSecondaryContainer = Color(0xFF4A4458)

private val ExpressiveDarkColors = darkColorScheme(
    primary = PixelDarkPrimary,
    onPrimary = Color(0xFF381E72),
    primaryContainer = PixelDarkPrimaryContainer,
    onPrimaryContainer = Color(0xFFEADDFF),
    secondary = Color(0xFFCCC2DC),
    secondaryContainer = PixelDarkSecondaryContainer,
    onSecondaryContainer = Color(0xFFE8DEF8),
    tertiary = Color(0xFFEFB8C8),
    background = PixelDarkSurface,
    surface = PixelDarkSurface,
    surfaceContainer = PixelDarkContainer,
    surfaceContainerHigh = PixelDarkContainerHigh,
    surfaceContainerHighest = Color(0xFF33333F),
    onSurface = Color(0xFFF2EFF7),
    onSurfaceVariant = Color(0xFFCAC4D0),
    outlineVariant = Color(0xFF49454F)
)

private val ExpressiveLightColors = lightColorScheme(
    primary = Color(0xFF6750A4),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFEADDFF),
    onPrimaryContainer = Color(0xFF21005D),
    secondaryContainer = Color(0xFFE8DEF8),
    onSecondaryContainer = Color(0xFF1D192B),
    background = Color(0xFFFAF8FF),
    surface = Color(0xFFFAF8FF),
    surfaceContainer = Color(0xFFF3EDF7),
    surfaceContainerHigh = Color(0xFFECE6F0),
    surfaceContainerHighest = Color(0xFFE6E0E9),
    onSurface = Color(0xFF1D1B20),
    onSurfaceVariant = Color(0xFF49454F)
)

@Composable
fun ExpressivePopupTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> ExpressiveDarkColors
        else -> ExpressiveLightColors
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
