package com.expressive.popupnotify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

class CallOverlayService : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!MainActivity.callPopupEnabled) return
        if (intent.action == TelephonyManager.ACTION_PHONE_STATE_CHANGED) {
            val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
            if (state == TelephonyManager.EXTRA_STATE_RINGING) {
                @Suppress("DEPRECATION")
                val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: "Incoming Voice Call"
                OverlayManager.showPopup(
                    context = context.applicationContext,
                    appName = "Phone",
                    title = incomingNumber,
                    message = "Swipe down pill to open in Floating Window",
                    config = MainActivity.currentConfig.copy(isCallPopup = true, durationSec = 10f),
                    targetPackage = "com.android.incallui"
                )
            } else if (state == TelephonyManager.EXTRA_STATE_IDLE || state == TelephonyManager.EXTRA_STATE_OFFHOOK) {
                OverlayManager.hidePopup()
            }
        }
    }
}
