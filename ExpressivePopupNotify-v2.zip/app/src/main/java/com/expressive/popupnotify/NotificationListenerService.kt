package com.expressive.popupnotify

import android.app.PendingIntent
import android.content.Context
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.expressive.popupnotify.ui.ExpressivePopupTheme
import com.expressive.popupnotify.ui.PopupConfig
import com.expressive.popupnotify.ui.PopupOrigin
import com.expressive.popupnotify.ui.PopupOverlayCard

data class ActivePopupData(
    val id: Int,
    val appName: String,
    val title: String,
    val message: String,
    val config: PopupConfig,
    val contentIntent: PendingIntent?,
    val targetPackage: String?
)

object OverlayManager {
    private var windowManager: WindowManager? = null
    private var composeView: ComposeView? = null
    private var visibleState by mutableStateOf(false)
    private var activeData by mutableStateOf<ActivePopupData?>(null)
    private var popupCounter by mutableIntStateOf(0)

    private val mainHandler = Handler(Looper.getMainLooper())
    private var dismissRunnable: Runnable? = null
    private var removeViewRunnable: Runnable? = null

    fun showPopup(
        context: Context,
        appName: String,
        title: String,
        message: String,
        config: PopupConfig,
        contentIntent: PendingIntent? = null,
        targetPackage: String? = null
    ) {
        if (!Settings.canDrawOverlays(context)) return

        mainHandler.post {
            dismissRunnable?.let { mainHandler.removeCallbacks(it) }
            removeViewRunnable?.let { mainHandler.removeCallbacks(it) }

            val wm = windowManager ?: (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).also {
                windowManager = it
            }

            if (composeView == null) {
                val owner = OverlayLifecycleOwner().apply { attachAndStart() }
                val view = ComposeView(context).apply {
                    setViewTreeLifecycleOwner(owner)
                    setViewTreeViewModelStoreOwner(owner)
                    setViewTreeSavedStateRegistryOwner(owner)
                }
                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                }
                wm.addView(view, params)
                composeView = view

                view.setContent {
                    ExpressivePopupTheme {
                        val data = activeData
                        if (data != null) {
                            val transformOrigin = when (data.config.origin) {
                                PopupOrigin.TOP_LEFT -> TransformOrigin(0.15f, 0f)
                                PopupOrigin.TOP_CENTER -> TransformOrigin(0.5f, 0f)
                                PopupOrigin.TOP_RIGHT -> TransformOrigin(0.85f, 0f)
                            }
                            AnimatedVisibility(
                                visible = visibleState,
                                enter = slideInVertically(
                                    initialOffsetY = { -it },
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioMediumBouncy,
                                        stiffness = Spring.StiffnessMediumLow
                                    )
                                ) + scaleIn(
                                    initialScale = 0.86f,
                                    transformOrigin = transformOrigin,
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioMediumBouncy,
                                        stiffness = Spring.StiffnessMediumLow
                                    )
                                ) + fadeIn(),
                                exit = slideOutVertically(
                                    targetOffsetY = { -it },
                                    animationSpec = spring(stiffness = Spring.StiffnessMedium)
                                ) + scaleOut(
                                    targetScale = 0.90f,
                                    transformOrigin = transformOrigin
                                ) + fadeOut()
                            ) {
                                PopupOverlayCard(
                                    context = context,
                                    appName = data.appName,
                                    title = data.title,
                                    message = data.message,
                                    config = data.config,
                                    contentIntent = data.contentIntent,
                                    targetPackage = data.targetPackage,
                                    onDismiss = { hidePopup() }
                                )
                            }
                        }
                    }
                }
            }

            popupCounter++
            activeData = ActivePopupData(
                id = popupCounter,
                appName = appName,
                title = title,
                message = message,
                config = config,
                contentIntent = contentIntent,
                targetPackage = targetPackage
            )
            visibleState = true

            val runnable = Runnable { hidePopup() }
            dismissRunnable = runnable
            mainHandler.postDelayed(runnable, (config.durationSec * 1000).toLong())
        }
    }

    fun hidePopup() {
        mainHandler.post {
            dismissRunnable?.let { mainHandler.removeCallbacks(it) }
            visibleState = false

            // Remove overlay view after exit animation completes so touches pass through cleanly
            removeViewRunnable?.let { mainHandler.removeCallbacks(it) }
            val cleanup = Runnable {
                try {
                    composeView?.let { windowManager?.removeViewImmediate(it) }
                } catch (_: Exception) { }
                composeView = null
                activeData = null
            }
            removeViewRunnable = cleanup
            mainHandler.postDelayed(cleanup, 360L)
        }
    }

    private class OverlayLifecycleOwner : LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
        private val registry = LifecycleRegistry(this)
        private val controller = SavedStateRegistryController.create(this)
        private val store = ViewModelStore()

        override val lifecycle: Lifecycle get() = registry
        override val viewModelStore: ViewModelStore get() = store
        override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry

        fun attachAndStart() {
            controller.performAttach()
            controller.performRestore(null)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_START)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        }
    }
}

class NotificationListenerService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        if (sbn.packageName == packageName) return
        if (sbn.isOngoing) return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString() ?: return
        val text = extras.getCharSequence("android.text")?.toString() ?: ""

        val appName = try {
            val appInfo = packageManager.getApplicationInfo(sbn.packageName, 0)
            packageManager.getApplicationLabel(appInfo).toString()
        } catch (_: Exception) {
            sbn.packageName
        }

        OverlayManager.showPopup(
            context = applicationContext,
            appName = appName,
            title = title,
            message = text,
            config = MainActivity.currentConfig.copy(isCallPopup = false),
            contentIntent = sbn.notification.contentIntent,
            targetPackage = sbn.packageName
        )
    }
}
