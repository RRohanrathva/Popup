package com.expressive.popupnotify.ui

import android.app.ActivityOptions
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.CallEnd
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

enum class PopupOrigin { TOP_LEFT, TOP_CENTER, TOP_RIGHT }

data class PopupConfig(
    val durationSec: Float = 4.5f,
    val cornerRadiusDp: Float = 32f,
    val glowEnabled: Boolean = true,
    val origin: PopupOrigin = PopupOrigin.TOP_CENTER,
    val isCallPopup: Boolean = false,
    val callAccentColor: Color = Color(0xFF2EE56B)
)

@Composable
fun PopupOverlayCard(
    context: Context,
    appName: String,
    title: String,
    message: String,
    config: PopupConfig,
    contentIntent: PendingIntent?,
    targetPackage: String?,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val dragY = remember { Animatable(0f) }

    LaunchedEffect(title, message, appName) {
        dragY.snapTo(0f)
    }

    val appIconBitmap = remember(targetPackage) {
        try {
            if (targetPackage != null) {
                val drawable = context.packageManager.getApplicationIcon(targetPackage)
                val bmp = Bitmap.createBitmap(
                    drawable.intrinsicWidth.coerceAtLeast(64),
                    drawable.intrinsicHeight.coerceAtLeast(64),
                    Bitmap.Config.ARGB_8888
                )
                val canvas = Canvas(bmp)
                drawable.setBounds(0, 0, canvas.width, canvas.height)
                drawable.draw(canvas)
                bmp.asImageBitmap()
            } else null
        } catch (_: Exception) {
            null
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "expressiveGlow")
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = if (config.glowEnabled) 0.35f else 0f,
        targetValue = if (config.glowEnabled) 0.95f else 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowPulse"
    )

    val callRingScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (config.isCallPopup) 1.08f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 650, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "callPulse"
    )

    val shape = RoundedCornerShape(config.cornerRadiusDp.dp)
    val accentColor = if (config.isCallPopup) config.callAccentColor else MaterialTheme.colorScheme.primary

    // Opaque PixelOS Android 17 surface tonal container (never transparent!)
    val cardBackgroundColor = if (config.isCallPopup) {
        Color(0xFF17261E)
    } else {
        MaterialTheme.colorScheme.surfaceContainerHigh
    }

    val dragScale = (1f - (kotlin.math.abs(dragY.value) / 1400f)).coerceIn(0.92f, 1.03f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = when (config.origin) {
            PopupOrigin.TOP_LEFT -> Alignment.TopStart
            PopupOrigin.TOP_CENTER -> Alignment.TopCenter
            PopupOrigin.TOP_RIGHT -> Alignment.TopEnd
        }
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(if (config.origin == PopupOrigin.TOP_CENTER) 1f else 0.90f)
                .offset { IntOffset(0, dragY.value.roundToInt()) }
                .graphicsLayer {
                    scaleX = dragScale
                    scaleY = dragScale
                }
                .pointerInput(title, message, targetPackage) {
                    detectVerticalDragGestures(
                        onVerticalDrag = { change, dragAmount ->
                            change.consume()
                            scope.launch {
                                dragY.snapTo((dragY.value + dragAmount).coerceIn(-380f, 340f))
                            }
                        },
                        onDragEnd = {
                            when {
                                // Swipe UP -> Dismiss immediately with spring exit
                                dragY.value < -65f -> {
                                    scope.launch {
                                        dragY.animateTo(
                                            -420f,
                                            spring(stiffness = Spring.StiffnessMedium)
                                        )
                                        onDismiss()
                                    }
                                }
                                // Swipe DOWN -> Open in HyperOS Freeform / Floating Window
                                dragY.value > 75f -> {
                                    launchInHyperOSFloatingWindow(context, targetPackage, contentIntent)
                                    onDismiss()
                                }
                                // Snap back smoothly with Expressive Spring
                                else -> {
                                    scope.launch {
                                        dragY.animateTo(
                                            0f,
                                            spring(
                                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                                stiffness = Spring.StiffnessMediumLow
                                            )
                                        )
                                    }
                                }
                            }
                        },
                        onDragCancel = {
                            scope.launch {
                                dragY.animateTo(0f, spring(dampingRatio = Spring.DampingRatioMediumBouncy))
                            }
                        }
                    )
                }
                .shadow(
                    elevation = if (config.glowEnabled) 20.dp else 10.dp,
                    shape = shape,
                    ambientColor = accentColor.copy(alpha = glowPulse),
                    spotColor = accentColor.copy(alpha = glowPulse)
                )
                .clip(shape)
                .clickable {
                    try {
                        contentIntent?.send()
                    } catch (_: Exception) {
                        targetPackage?.let { pkg ->
                            context.packageManager.getLaunchIntentForPackage(pkg)?.apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }?.let { context.startActivity(it) }
                        }
                    }
                    onDismiss()
                },
            shape = shape,
            color = cardBackgroundColor,
            tonalElevation = 8.dp,
            border = BorderStroke(
                width = if (config.glowEnabled) 2.dp else 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        accentColor.copy(alpha = if (config.glowEnabled) glowPulse else 0.35f),
                        MaterialTheme.colorScheme.tertiary.copy(alpha = if (config.glowEnabled) glowPulse * 0.85f else 0.2f),
                        accentColor.copy(alpha = if (config.glowEnabled) glowPulse else 0.35f)
                    )
                )
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Squircle / Expressive Pill Icon Container
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .scale(callRingScale)
                            .clip(RoundedCornerShape(16.dp))
                            .background(accentColor.copy(alpha = 0.22f)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (config.isCallPopup) {
                            Icon(
                                imageVector = Icons.Rounded.Call,
                                contentDescription = "Incoming Call",
                                tint = accentColor,
                                modifier = Modifier.size(24.dp)
                            )
                        } else if (appIconBitmap != null) {
                            Image(
                                bitmap = appIconBitmap,
                                contentDescription = appName,
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.Notifications,
                                contentDescription = appName,
                                tint = accentColor,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = accentColor.copy(alpha = 0.18f)
                            ) {
                                Text(
                                    text = if (config.isCallPopup) "INCOMING CALL" else appName,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = accentColor
                                )
                            }
                            Text(
                                text = "• now",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(3.dp))

                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        if (message.isNotBlank()) {
                            Text(
                                text = message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                // PixelOS Android 17 Pill Action Chips for Incoming Call
                if (config.isCallPopup) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onDismiss() },
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp),
                            shape = CircleShape,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFE53935),
                                contentColor = Color.White
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp)
                        ) {
                            Icon(Icons.Rounded.CallEnd, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Decline", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Button(
                            onClick = {
                                launchInHyperOSFloatingWindow(context, targetPackage, contentIntent)
                                onDismiss()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp),
                            shape = CircleShape,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF2EE56B),
                                contentColor = Color(0xFF00210B)
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp)
                        ) {
                            Icon(Icons.Rounded.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Answer", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Expressive Bottom Gesture Handle Pill (Swipe Down = HyperOS Floating Window, Swipe Up = Dismiss)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.7f))
                        .clickable {
                            launchInHyperOSFloatingWindow(context, targetPackage, contentIntent)
                            onDismiss()
                        }
                        .padding(vertical = 5.dp, horizontal = 12.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.KeyboardArrowDown,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Box(
                        modifier = Modifier
                            .width(36.dp)
                            .height(4.dp)
                            .clip(CircleShape)
                            .background(accentColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (dragY.value > 25f) "Release for Floating Window!" else "Swipe down • Floating Window",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (dragY.value > 25f) accentColor else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Rounded.OpenInNew,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
    }
}

private fun launchInHyperOSFloatingWindow(
    context: Context,
    packageName: String?,
    contentIntent: PendingIntent?
) {
    try {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getMetrics(dm)
        val screenW = dm.widthPixels
        val screenH = dm.heightPixels

        // HyperOS / Android Freeform Floating Window Bounds (Centered compact floating card)
        val left = (screenW * 0.08f).toInt()
        val top = (screenH * 0.14f).toInt()
        val right = (screenW * 0.92f).toInt()
        val bottom = (screenH * 0.68f).toInt()
        val freeformBounds = Rect(left, top, right, bottom)

        val options = ActivityOptions.makeBasic().apply {
            setLaunchBounds(freeformBounds)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                try {
                    // WindowConfiguration.WINDOWING_MODE_FREEFORM = 5
                    val method = ActivityOptions::class.java.getMethod(
                        "setLaunchWindowingMode",
                        Int::class.javaPrimitiveType
                    )
                    method.invoke(this, 5)
                } catch (_: Exception) { }
            }
        }

        val launchIntent = if (packageName != null) {
            context.packageManager.getLaunchIntentForPackage(packageName)
        } else {
            null
        }

        if (launchIntent != null) {
            launchIntent.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK or
                    Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT
            )
            // HyperOS / MIUI specific freeform extras
            launchIntent.putExtra("android.intent.extra.FREEFORM", true)
            launchIntent.putExtra("miui.intent.extra.OPEN_IN_FREEFORM", true)
            context.startActivity(launchIntent, options.toBundle())
            return
        }

        if (contentIntent != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                options.setPendingIntentBackgroundActivityStartMode(
                    ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                )
            }
            contentIntent.send(context, 0, null, null, null, null, options.toBundle())
        }
    } catch (_: Exception) {
        try {
            contentIntent?.send()
        } catch (_: Exception) { }
    }
}
