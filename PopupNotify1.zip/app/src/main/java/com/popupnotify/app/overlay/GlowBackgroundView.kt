package com.popupnotify.app.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Draws the rounded card, its soft shadow, the rotating glow border and the countdown line.
 * It is the only software-layer view (needed for blur); all content sits above it in hardware.
 */
class GlowBackgroundView(context: Context) : View(context) {

    var cornerPx = 0f
    var inset = 0f
    var fillColor = 0
    var glowEnabled = true
    var glowColors: IntArray = intArrayOf()
    var glowStrokePx = 4f
    var glowIntensity = 0.7f
    var glowSpeed = 4f
    var progress = -1f
        set(v) { field = v; invalidate() }
    var progressColor = 0
    var trackColor = 0

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val blurPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val rect = RectF()
    private val matrix = Matrix()
    private var shader: SweepGradient? = null
    private var angle = 0f
    private var animator: ValueAnimator? = null

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun applyGlow() {
        rebuildShader()
        blurPaint.maskFilter = BlurMaskFilter(max(1f, inset * 0.55f), BlurMaskFilter.Blur.NORMAL)
        if (isAttachedToWindow) restartAnimator()
        invalidate()
    }

    private fun rebuildShader() {
        if (width == 0 || height == 0 || glowColors.size < 2) {
            shader = null
            return
        }
        shader = SweepGradient(width / 2f, height / 2f, glowColors, null)
    }

    private fun restartAnimator() {
        animator?.cancel()
        animator = null
        if (!glowEnabled || glowSpeed <= 0f) return
        animator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = (12000f / glowSpeed.coerceIn(0.5f, 12f)).toLong()
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                angle = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuildShader()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        restartAnimator()
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        rect.set(inset, inset, width - inset, height - inset)

        fillPaint.color = fillColor
        fillPaint.setShadowLayer(inset * 0.8f, 0f, inset * 0.22f, 0x55000000)
        canvas.drawRoundRect(rect, cornerPx, cornerPx, fillPaint)

        val sh = shader
        if (glowEnabled && sh != null) {
            matrix.setRotate(angle, width / 2f, height / 2f)
            sh.setLocalMatrix(matrix)
            val pulse = 0.78f + 0.22f * sin(Math.toRadians(angle * 2.0)).toFloat()

            blurPaint.shader = sh
            blurPaint.strokeWidth = glowStrokePx * 2.4f
            blurPaint.alpha = (255f * min(1f, glowIntensity * pulse)).toInt()
            canvas.drawRoundRect(rect, cornerPx, cornerPx, blurPaint)

            strokePaint.shader = sh
            strokePaint.strokeWidth = glowStrokePx
            strokePaint.alpha = (255f * min(1f, 0.35f + glowIntensity)).toInt()
            canvas.drawRoundRect(rect, cornerPx, cornerPx, strokePaint)
        }

        if (progress >= 0f) {
            val sw = max(2f, glowStrokePx * 0.9f)
            val y = rect.bottom - sw * 2.4f
            val l = rect.left + cornerPx * 0.8f
            val r = rect.right - cornerPx * 0.8f
            if (r > l) {
                linePaint.strokeWidth = sw
                linePaint.color = trackColor
                canvas.drawLine(l, y, r, y, linePaint)
                linePaint.color = progressColor
                canvas.drawLine(l, y, l + (r - l) * progress.coerceIn(0f, 1f), y, linePaint)
            }
        }
    }
}
