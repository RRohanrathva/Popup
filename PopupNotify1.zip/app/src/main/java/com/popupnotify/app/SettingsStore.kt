package com.popupnotify.app

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf

class BoolPref(private val sp: SharedPreferences, private val key: String, default: Boolean) {
    private val state = mutableStateOf(sp.getBoolean(key, default))
    var value: Boolean
        get() = state.value
        set(v) {
            state.value = v
            sp.edit().putBoolean(key, v).apply()
        }
}

class FloatPref(private val sp: SharedPreferences, private val key: String, default: Float) {
    private val state = mutableStateOf(sp.getFloat(key, default))
    var value: Float
        get() = state.value
        set(v) {
            state.value = v
            sp.edit().putFloat(key, v).apply()
        }
}

class IntPref(private val sp: SharedPreferences, private val key: String, default: Int) {
    private val state = mutableStateOf(sp.getInt(key, default))
    var value: Int
        get() = state.value
        set(v) {
            state.value = v
            sp.edit().putInt(key, v).apply()
        }
}

/** Every user customisation lives here. Compose reads the same states the overlay reads. */
class SettingsStore private constructor(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("popup_settings", Context.MODE_PRIVATE)

    // ---- General popup ----
    val popupEnabled = BoolPref(sp, "popup_enabled", true)
    val durationSec = FloatPref(sp, "duration_sec", 5f)
    val corner = FloatPref(sp, "corner_dp", 28f)
    val widthPct = FloatPref(sp, "width_pct", 94f)
    val bgOpacity = FloatPref(sp, "bg_opacity", 100f)
    val topOffset = FloatPref(sp, "top_offset_dp", 6f)
    val position = IntPref(sp, "position", 1)          // 0 left, 1 center, 2 right
    val entryAnim = IntPref(sp, "entry_anim", 0)       // see EntryStyle
    val animationsOn = BoolPref(sp, "animations_on", true)
    val animSpeed = FloatPref(sp, "anim_speed", 1f)    // 0.5 .. 2.0
    val showProgress = BoolPref(sp, "show_progress", false)
    val haptic = BoolPref(sp, "haptic", true)
    val ignoreOngoing = BoolPref(sp, "ignore_ongoing", true)
    val showActions = BoolPref(sp, "show_actions", true)
    val showChips = BoolPref(sp, "show_chips", true)
    val showHandle = BoolPref(sp, "show_handle", true)
    val floatGesture = BoolPref(sp, "float_gesture", true)

    // ---- Glow ----
    val glowOn = BoolPref(sp, "glow_on", false)
    val glowMode = IntPref(sp, "glow_mode", 0)         // 0 system accent, 1 rainbow, 2 custom
    val glowColor = IntPref(sp, "glow_color", 0xFF7C4DFF.toInt())
    val glowSpeed = FloatPref(sp, "glow_speed", 4f)    // 1 .. 10
    val glowWidth = FloatPref(sp, "glow_width_dp", 2.5f)
    val glowIntensity = FloatPref(sp, "glow_intensity", 70f)

    // ---- Call popup ----
    val callEnabled = BoolPref(sp, "call_enabled", true)
    val callPosition = IntPref(sp, "call_position", 0) // 0 top, 1 center, 2 bottom
    val callStyle = IntPref(sp, "call_style", 0)       // 0 compact, 1 large
    val callCorner = FloatPref(sp, "call_corner_dp", 32f)
    val callGlowOn = BoolPref(sp, "call_glow_on", true)
    val callGlowColor = IntPref(sp, "call_glow_color", 0xFF34C759.toInt())
    val callGlowSpeed = FloatPref(sp, "call_glow_speed", 6f)
    val callRingAnim = BoolPref(sp, "call_ring_anim", true)
    val answerColor = IntPref(sp, "answer_color", 0xFF2E9E5B.toInt())
    val declineColor = IntPref(sp, "decline_color", 0xFFE5484D.toInt())

    // ---- Per-app block list ----
    private val blockedState = mutableStateOf(sp.getStringSet("blocked", emptySet())?.toSet() ?: emptySet())
    val blocked: Set<String> get() = blockedState.value

    fun setBlocked(pkg: String, block: Boolean) {
        val next = if (block) blockedState.value + pkg else blockedState.value - pkg
        blockedState.value = next
        sp.edit().putStringSet("blocked", next).apply()
    }

    companion object {
        @Volatile private var instance: SettingsStore? = null
        fun get(context: Context): SettingsStore =
            instance ?: synchronized(this) {
                instance ?: SettingsStore(context).also { instance = it }
            }
    }
}

object EntryStyle {
    const val SLIDE_TOP = 0
    const val SLIDE_SIDE = 1
    const val POP = 2
    const val FADE_DROP = 3
    const val ELASTIC = 4
    val names = listOf("Slide down", "Slide from side", "Pop", "Soft drop", "Elastic")
}
