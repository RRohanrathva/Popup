package com.popupnotify.app.overlay

import android.app.PendingIntent
import android.app.RemoteInput
import android.graphics.drawable.Drawable

/** One action button from the original notification (Mark as read, Reply, ...). */
class PopupAction(
    val title: String,
    val intent: PendingIntent?,
    val remoteInputs: Array<RemoteInput>?,
    val choices: List<String>,
    val isReply: Boolean,
) {
    /** Smart-reply style action: only offers fixed choices, no free typing. */
    val choicesOnly: Boolean get() = choices.isNotEmpty() && !isReply
}

data class PopupData(
    val key: String,
    val pkg: String,
    val appName: String,
    val title: String,
    val text: String,
    val appIcon: Drawable?,
    val largeIcon: Drawable?,
    val contentIntent: PendingIntent?,
    val isCall: Boolean,
    val answer: PendingIntent?,
    val decline: PendingIntent?,
    val actions: List<PopupAction> = emptyList(),
)
