package com.popupnotify.app.overlay

import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import com.popupnotify.app.EntryStyle
import java.util.WeakHashMap
import kotlin.math.abs
import kotlin.math.min

object PopupAnim {

    private val running = WeakHashMap<View, MutableList<SpringAnimation>>()

    private fun spring(
        v: View,
        prop: DynamicAnimation.ViewProperty,
        from: Float,
        to: Float,
        damping: Float,
        stiffness: Float,
    ) {
        val anim = SpringAnimation(v, prop, to)
        anim.spring.dampingRatio = damping
        anim.spring.stiffness = stiffness
        anim.setStartValue(from)
        running.getOrPut(v) { mutableListOf() }.add(anim)
        anim.start()
    }

    fun cancelSprings(v: View) {
        running.remove(v)?.forEach { if (it.isRunning) it.cancel() }
        v.animate().cancel()
    }

    /** [scale] is the global animation speed; 0 means animations are off. */
    fun enter(v: View, style: Int, position: Int, scale: Float, screenW: Int) {
        val d = v.resources.displayMetrics.density
        v.pivotX = v.width / 2f
        v.pivotY = 0f
        v.translationX = 0f
        v.translationY = 0f
        v.scaleX = 1f
        v.scaleY = 1f
        if (scale <= 0f) {
            v.alpha = 1f
            return
        }
        val k = scale.coerceIn(0.4f, 2.5f)
        val h = v.height.toFloat()
        v.alpha = 0f
        v.animate().alpha(1f).setDuration((200 / k).toLong()).start()

        when (style) {
            EntryStyle.SLIDE_SIDE -> {
                if (position == 1) {
                    v.translationY = -(h + 40 * d)
                    spring(v, DynamicAnimation.TRANSLATION_Y, v.translationY, 0f, 0.7f, 320f * k)
                } else {
                    val from = if (position == 0) -screenW.toFloat() else screenW.toFloat()
                    v.translationX = from
                    spring(v, DynamicAnimation.TRANSLATION_X, from, 0f, 0.72f, 300f * k)
                }
            }
            EntryStyle.POP -> {
                v.scaleX = 0.55f
                v.scaleY = 0.55f
                v.translationY = -18 * d
                spring(v, DynamicAnimation.SCALE_X, 0.55f, 1f, 0.5f, 420f * k)
                spring(v, DynamicAnimation.SCALE_Y, 0.55f, 1f, 0.5f, 420f * k)
                spring(v, DynamicAnimation.TRANSLATION_Y, -18 * d, 0f, 0.6f, 380f * k)
            }
            EntryStyle.FADE_DROP -> {
                v.translationY = -34 * d
                spring(v, DynamicAnimation.TRANSLATION_Y, -34 * d, 0f, 1f, 190f * k)
            }
            EntryStyle.ELASTIC -> {
                v.scaleY = 0.3f
                v.scaleX = 1.14f
                v.translationY = -h * 0.5f
                spring(v, DynamicAnimation.SCALE_Y, 0.3f, 1f, 0.38f, 300f * k)
                spring(v, DynamicAnimation.SCALE_X, 1.14f, 1f, 0.45f, 300f * k)
                spring(v, DynamicAnimation.TRANSLATION_Y, -h * 0.5f, 0f, 0.55f, 300f * k)
            }
            else -> { // SLIDE_TOP
                v.translationY = -(h + 40 * d)
                spring(v, DynamicAnimation.TRANSLATION_Y, v.translationY, 0f, 0.62f, 340f * k)
            }
        }
    }

    fun exit(v: View, style: Int, position: Int, scale: Float, screenW: Int, end: () -> Unit) {
        cancelSprings(v)
        if (scale <= 0f) {
            end()
            return
        }
        val d = v.resources.displayMetrics.density
        val k = scale.coerceIn(0.4f, 2.5f)
        val h = v.height.toFloat()
        val a = v.animate().alpha(0f).setDuration((230 / k).toLong())
            .setInterpolator(AccelerateInterpolator(1.3f))
        when (style) {
            EntryStyle.SLIDE_SIDE ->
                if (position == 1) a.translationY(-(h + 40 * d))
                else a.translationX(if (position == 0) -screenW.toFloat() else screenW.toFloat())
            EntryStyle.POP -> a.scaleX(0.7f).scaleY(0.7f).translationY(-10 * d)
            EntryStyle.FADE_DROP -> a.translationY(-20 * d)
            EntryStyle.ELASTIC -> a.scaleY(0.4f).translationY(-h * 0.4f)
            else -> a.translationY(-(h + 40 * d))
        }
        a.withEndAction(end).start()
    }

    /** Fade-and-lift for the inner views so the content arrives a beat after the card. */
    fun stagger(views: List<View>, scale: Float) {
        if (scale <= 0f) return
        val k = scale.coerceIn(0.4f, 2.5f)
        val d = views.firstOrNull()?.resources?.displayMetrics?.density ?: 3f
        views.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = 10 * d
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(((110 + i * 55) / k).toLong())
                .setDuration((280 / k).toLong())
                .setInterpolator(DecelerateInterpolator(1.6f))
                .start()
        }
    }

    fun popIn(v: View, scale: Float, delayMs: Long = 90) {
        if (scale <= 0f) return
        val k = scale.coerceIn(0.4f, 2.5f)
        v.scaleX = 0.3f
        v.scaleY = 0.3f
        v.animate().scaleX(1f).scaleY(1f).setStartDelay((delayMs / k).toLong())
            .setDuration((420 / k).toLong()).setInterpolator(OvershootInterpolator(2.4f)).start()
    }

    /** Press feedback: shrinks on touch and springs back. Returns false so clicks still fire. */
    fun pressable(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.9f).scaleY(0.9f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(260)
                        .setInterpolator(OvershootInterpolator(3f)).start()
            }
            false
        }
    }
}

/** Tap to open, drag sideways or flick up to dismiss, touch-and-hold pauses the timer. */
class SwipeTouchListener(
    private val target: View,
    private val onTap: () -> Unit,
    private val onFling: (dx: Float, up: Boolean) -> Unit,
    private val onHold: (Boolean) -> Unit,
    private val onOutside: () -> Unit = {},
) : View.OnTouchListener {

    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private val slop = ViewConfiguration.get(target.context).scaledTouchSlop

    override fun onTouch(v: View, e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                dragging = false
                onHold(true)
                PopupAnim.cancelSprings(target)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = min(0f, e.rawY - downY)
                if (!dragging && (abs(dx) > slop || -dy > slop)) dragging = true
                if (dragging) {
                    target.translationX = dx
                    target.translationY = dy
                    target.alpha = (1f - abs(dx) / (target.width * 0.9f)).coerceIn(0.2f, 1f)
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                val dx = e.rawX - downX
                val dy = min(0f, e.rawY - downY)
                when {
                    !dragging -> {
                        onHold(false)
                        onTap()
                    }
                    abs(dx) > target.width * 0.33f -> onFling(dx, false)
                    -dy > target.height * 0.55f -> onFling(0f, true)
                    else -> {
                        springBack()
                        onHold(false)
                    }
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                springBack()
                onHold(false)
                return true
            }
            MotionEvent.ACTION_OUTSIDE -> {
                onOutside()
                return true
            }
        }
        return false
    }

    private fun springBack() {
        target.animate().translationX(0f).translationY(0f).alpha(1f)
            .setDuration(260).setInterpolator(OvershootInterpolator(1.4f)).start()
    }
}
