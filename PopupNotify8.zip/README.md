# Popup Notify

Floating (heads-up style) notification popups with Material 3 Expressive design.

## Build APK on GitHub
1. Upload the whole project contents to a new GitHub repo (branch `main`).
2. Open the **Actions** tab, run **Build APK** (it also runs on every push).
3. When it finishes, download `PopupNotify-APK` from the run's **Artifacts**.

## First run on the phone
1. Install the APK, open it.
2. Allow **Display over other apps** and **Notification access**.
3. Redmi / HyperOS: enable Autostart, set Battery saver to No restrictions, lock the app in Recents.
