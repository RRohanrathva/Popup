package com.popupnotify.app.overlay

import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import com.popupnotify.app.EntryStyle
import java.util.WeakHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sign

object PopupAnim {

    private val running = WeakHashMap<View, MutableList<SpringAnimation>>()
    private val runningTimed = WeakHashMap<View, MutableList<android.animation.Animator>>()

    /** Chosen in settings: 0 spring, 1 bounce, 2 cubic, 3 quart, 4 sine, 5 decelerate, 6 overshoot. */
    @Volatile var curve = 0
    /** Spring "response" in seconds (smaller = snappier) and damping (1 = no bounce). Defaults change nothing. */
    @Volatile var response = 0.35f
    @Volatile var damping = 0.7f

    private fun androidProp(p: DynamicAnimation.ViewProperty): android.util.Property<View, Float>? = when {
        p === DynamicAnimation.TRANSLATION_X -> View.TRANSLATION_X
        p === DynamicAnimation.TRANSLATION_Y -> View.TRANSLATION_Y
        p === DynamicAnimation.SCALE_X -> View.SCALE_X
        p === DynamicAnimation.SCALE_Y -> View.SCALE_Y
        else -> null
    }

    private fun curveInterpolator(c: Int): android.view.animation.Interpolator = when (c) {
        1 -> android.view.animation.BounceInterpolator()
        2 -> android.view.animation.PathInterpolator(0.33f, 1f, 0.68f, 1f)   // ease out cubic
        3 -> android.view.animation.PathInterpolator(0.25f, 1f, 0.5f, 1f)    // ease out quart
        4 -> android.view.animation.PathInterpolator(0.61f, 1f, 0.88f, 1f)   // ease out sine
        5 -> DecelerateInterpolator(2f)
        else -> OvershootInterpolator(1.8f)
    }

    /** Curve based (non spring) move. The spring stiffness the caller passes also tells us the speed. */
    private fun timed(v: View, prop: DynamicAnimation.ViewProperty, from: Float, to: Float, stiffness: Float) {
        val p = androidProp(prop)
        if (p == null) {
            prop.setValue(v, to)
            return
        }
        val dur = (520f * kotlin.math.sqrt(320f / stiffness.coerceAtLeast(60f)) * (response / 0.35f))
            .toLong().coerceIn(160L, 1500L)
        val a = android.animation.ObjectAnimator.ofFloat(v, p, from, to)
        a.duration = dur
        a.interpolator = curveInterpolator(curve)
        runningTimed.getOrPut(v) { mutableListOf() }.add(a)
        a.start()
    }

    private fun spring(
        v: View,
        prop: DynamicAnimation.ViewProperty,
        from: Float,
        to: Float,
        damping: Float,
        stiffness: Float,
    ) {
        if (curve != 0) {
            timed(v, prop, from, to, stiffness)
            return
        }
        val anim = SpringAnimation(v, prop, to)
        anim.spring.dampingRatio = (damping * (this.damping / 0.7f)).coerceIn(0.25f, 1f)
        val r = (0.35f / response.coerceIn(0.12f, 1f))
        anim.spring.stiffness = stiffness * r * r
        anim.setStartValue(from)
        running.getOrPut(v) { mutableListOf() }.add(anim)
        anim.start()
    }

    fun cancelSprings(v: View) {
        running.remove(v)?.forEach { if (it.isRunning) it.cancel() }
        runningTimed.remove(v)?.forEach { it.cancel() }
        v.animate().cancel()
    }

    /** How far a slide travels. It must fit in the spare room the overlay window keeps around the card. */
    private fun travel(h: Float, d: Float, vert: Int): Float =
        if (vert == 1) 26 * d else minOf(h + 40 * d, 200 * d)

    /** vert: 0 top, 1 middle, 2 bottom. The popup always travels in from its own edge. */
    fun enter(v: View, style: Int, position: Int, scale: Float, screenW: Int, vert: Int = 0) {
        val d = v.resources.displayMetrics.density
        val sg = if (vert == 2) 1f else -1f
        v.pivotX = v.width / 2f
        v.pivotY = if (vert == 2) v.height.toFloat() else if (vert == 1) v.height / 2f else 0f
        v.translationX = 0f
        v.translationY = 0f
        v.scaleX = 1f
        v.scaleY = 1f
        if (scale <= 0f) {
            v.alpha = 1f
            return
        }
        val k = scale.coerceIn(0.4f, 2.5f)
        val h = v.height.toFloat()
        v.alpha = 0f
        v.animate().alpha(1f).setDuration((200 / k).toLong()).start()

        when (style) {
            EntryStyle.SLIDE_SIDE -> {
                if (position == 1) {
                    v.translationY = sg * travel(h, d, vert)
                    spring(v, DynamicAnimation.TRANSLATION_Y, v.translationY, 0f, 0.7f, 320f * k)
                } else {
                    val from = if (position == 0) -screenW.toFloat() else screenW.toFloat()
                    v.translationX = from
                    spring(v, DynamicAnimation.TRANSLATION_X, from, 0f, 0.72f, 300f * k)
                }
            }
            EntryStyle.POP -> {
                v.scaleX = 0.55f
                v.scaleY = 0.55f
                v.translationY = sg * 18 * d
                spring(v, DynamicAnimation.SCALE_X, 0.55f, 1f, 0.5f, 420f * k)
                spring(v, DynamicAnimation.SCALE_Y, 0.55f, 1f, 0.5f, 420f * k)
                spring(v, DynamicAnimation.TRANSLATION_Y, sg * 18 * d, 0f, 0.6f, 380f * k)
            }
            EntryStyle.FADE_DROP -> {
                v.translationY = sg * 34 * d
                spring(v, DynamicAnimation.TRANSLATION_Y, sg * 34 * d, 0f, 1f, 190f * k)
            }
            EntryStyle.ELASTIC -> {
                v.scaleY = 0.3f
                v.scaleX = 1.14f
                v.translationY = sg * h * 0.5f
                spring(v, DynamicAnimation.SCALE_Y, 0.3f, 1f, 0.38f, 300f * k)
                spring(v, DynamicAnimation.SCALE_X, 1.14f, 1f, 0.45f, 300f * k)
                spring(v, DynamicAnimation.TRANSLATION_Y, sg * h * 0.5f, 0f, 0.55f, 300f * k)
            }
            else -> {
                v.translationY = sg * travel(h, d, vert)
                spring(v, DynamicAnimation.TRANSLATION_Y, v.translationY, 0f, 0.62f, 340f * k)
            }
        }
    }

    fun exit(v: View, style: Int, position: Int, scale: Float, screenW: Int, vert: Int = 0, end: () -> Unit) {
        cancelSprings(v)
        if (scale <= 0f) {
            end()
            return
        }
        val sg = if (vert == 2) 1f else -1f
        val d = v.resources.displayMetrics.density
        val k = scale.coerceIn(0.4f, 2.5f)
        val h = v.height.toFloat()
        val a = v.animate().alpha(0f).setDuration((230 / k).toLong())
            .setInterpolator(AccelerateInterpolator(1.3f))
        when (style) {
            EntryStyle.SLIDE_SIDE ->
                if (position == 1) a.translationY(sg * travel(h, d, vert))
                else a.translationX(if (position == 0) -screenW.toFloat() else screenW.toFloat())
            EntryStyle.POP -> a.scaleX(0.7f).scaleY(0.7f).translationY(sg * 10 * d)
            EntryStyle.FADE_DROP -> a.translationY(sg * 20 * d)
            EntryStyle.ELASTIC -> a.scaleY(0.4f).translationY(sg * h * 0.4f)
            else -> a.translationY(sg * travel(h, d, vert))
        }
        a.withEndAction(end).start()
    }

    /** Fade-and-lift for the inner views so the content arrives a beat after the card. */
    fun stagger(views: List<View>, scale: Float) {
        if (scale <= 0f) return
        val k = scale.coerceIn(0.4f, 2.5f)
        val d = views.firstOrNull()?.resources?.displayMetrics?.density ?: 3f
        views.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = 10 * d
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(((110 + i * 55) / k).toLong())
                .setDuration((280 / k).toLong())
                .setInterpolator(DecelerateInterpolator(1.6f))
                .start()
        }
    }

    fun popIn(v: View, scale: Float, delayMs: Long = 90) {
        if (scale <= 0f) return
        val k = scale.coerceIn(0.4f, 2.5f)
        v.scaleX = 0.3f
        v.scaleY = 0.3f
        v.animate().scaleX(1f).scaleY(1f).setStartDelay((delayMs / k).toLong())
            .setDuration((420 / k).toLong()).setInterpolator(OvershootInterpolator(2.4f)).start()
    }

    /** Layers tucking in behind the card: they rise into place with a bounce. */
    fun tuckIn(v: View, index: Int, scale: Float) {
        if (scale <= 0f) return
        val k = scale.coerceIn(0.4f, 2.5f)
        val d = v.resources.displayMetrics.density
        v.alpha = 0f
        v.scaleX = 0.86f
        v.translationY = -22 * d
        v.animate().alpha(1f).scaleX(1f).translationY(0f)
            .setStartDelay(((60 + index * 70) / k).toLong())
            .setDuration((420 / k).toLong()).setInterpolator(OvershootInterpolator(1.6f)).start()
    }

    /** The card that was underneath comes up to the top: it grows from its tucked-in size with a soft bounce. */
    fun promote(v: View, vert: Int, scale: Float) {
        val d = v.resources.displayMetrics.density
        val sg = if (vert == 2) -1f else 1f
        v.pivotX = v.width / 2f
        v.pivotY = if (vert == 2) v.height.toFloat() else if (vert == 1) v.height / 2f else 0f
        v.alpha = 1f
        v.translationX = 0f
        if (scale <= 0f) {
            v.translationY = 0f
            v.scaleX = 1f
            v.scaleY = 1f
            return
        }
        val k = scale.coerceIn(0.4f, 2.5f)
        v.scaleX = 0.93f
        v.scaleY = 0.93f
        v.translationY = sg * 12 * d
        spring(v, DynamicAnimation.SCALE_X, 0.93f, 1f, 0.55f, 420f * k)
        spring(v, DynamicAnimation.SCALE_Y, 0.93f, 1f, 0.55f, 420f * k)
        spring(v, DynamicAnimation.TRANSLATION_Y, sg * 12 * d, 0f, 0.6f, 380f * k)
    }

    /** Press feedback: shrinks on touch and springs back. Returns false so clicks still fire. */
    fun pressable(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.9f).scaleY(0.9f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(260)
                        .setInterpolator(OvershootInterpolator(3f)).start()
            }
            false
        }
    }
}

/**
 * Tap opens the app. Drag or flick sideways, or toward [dir] (-1 up, 1 down, 0 both), to dismiss.
 * Touching and holding pauses the timer. Works even when a child button was pressed first and the
 * parent then stole the gesture.
 */
class SwipeTouchListener(
    private val target: View,
    private val dir: Int,
    private val onTap: () -> Unit,
    private val onFling: (dx: Float, dirY: Float) -> Unit,
    private val onHold: (Boolean) -> Unit,
    private val onOutside: () -> Unit = {},
) : View.OnTouchListener {

    private var downX = 0f
    private var downY = 0f
    private var started = false
    private var dragging = false
    private var moved = false
    private var vt: VelocityTracker? = null
    private val slop = ViewConfiguration.get(target.context).scaledTouchSlop

    private fun begin(e: MotionEvent) {
        downX = e.rawX
        downY = e.rawY
        started = true
        dragging = false
        moved = false
        vt?.recycle()
        vt = VelocityTracker.obtain()
        vt?.addMovement(e)
        onHold(true)
        PopupAnim.cancelSprings(target)
    }

    private fun allowedDy(dy: Float): Float = when (dir) {
        -1 -> min(0f, dy)
        1 -> max(0f, dy)
        else -> dy
    }

    private fun finish() {
        started = false
        vt?.recycle()
        vt = null
    }

    override fun onTouch(v: View, e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                begin(e)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!started) { begin(e); moved = true }
                vt?.addMovement(e)
                val dx = e.rawX - downX
                val dyRaw = e.rawY - downY
                val dy = allowedDy(dyRaw)
                if (abs(dx) > slop || abs(dyRaw) > slop) moved = true
                if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                if (dragging) {
                    target.translationX = dx
                    target.translationY = dy
                    val fx = abs(dx) / (target.width * 0.9f)
                    val fy = abs(dy) / (target.height * 1.1f)
                    target.alpha = (1f - max(fx, fy)).coerceIn(0.2f, 1f)
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!started) return true
                vt?.addMovement(e)
                vt?.computeCurrentVelocity(1000)
                val vx = vt?.xVelocity ?: 0f
                val vy = vt?.yVelocity ?: 0f
                val dx = e.rawX - downX
                val dy = allowedDy(e.rawY - downY)
                finish()
                when {
                    !moved -> {
                        onHold(false)
                        onTap()
                    }
                    abs(dx) > target.width * 0.3f || (abs(vx) > 900f && abs(dx) > slop) -> onFling(dx, 0f)
                    abs(dy) > target.height * 0.28f ||
                        (abs(vy) > 700f && abs(dy) > slop && sign(vy) == sign(dy)) ->
                        onFling(0f, if (dir != 0) dir.toFloat() else sign(dy))
                    else -> {
                        springBack()
                        onHold(false)
                    }
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                finish()
                springBack()
                onHold(false)
                return true
            }
            MotionEvent.ACTION_OUTSIDE -> {
                onOutside()
                return true
            }
        }
        return false
    }

    private fun springBack() {
        target.animate().translationX(0f).translationY(0f).alpha(1f)
            .setDuration(260).setInterpolator(OvershootInterpolator(1.4f)).start()
    }
}
