package com.popupnotify.app.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import com.popupnotify.app.R
import com.popupnotify.app.SettingsStore

/** Expanding rings behind the caller avatar. */
private class RingView(ctx: Context, private val color: Int) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dp(2f) }
    private var t = 0f
    private var anim: ValueAnimator? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1800
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = minOf(width, height) * 0.30f
        val max = minOf(width, height) / 2f
        for (i in 0..2) {
            val p = (t + i / 3f) % 1f
            paint.color = color
            paint.alpha = ((1f - p) * 150).toInt()
            c.drawCircle(cx, cy, base + (max - base) * p, paint)
        }
    }
}

class CallPopup(
    private val ctx: Context,
    private val s: SettingsStore,
    private val mgr: OverlayManager,
) {
    fun build(d: PopupData) {
        val pal = ctx.popupPalette(s.bgOpacity.value)
        val large = s.callStyle.value == 1
        val corner = ctx.dp(s.callCorner.value)
        val inset = ctx.dp(10f)
        val avatarSize = ctx.dpi(if (large) 72f else 52f)

        val card = KeyFrame(ctx) { mgr.dismissAnimated() }
        val bg = GlowBackgroundView(ctx).apply {
            cornerPx = corner
            this.inset = inset
            fillColor = pal.bg
            glowEnabled = s.callGlowOn.value
            glowColors = loopColors(2, pal.accent, s.callGlowColor.value)
            glowStrokePx = ctx.dp(3f)
            glowIntensity = 0.9f
            glowSpeed = if (s.animationsOn.value) s.callGlowSpeed.value * s.animSpeed.value else 0f
            progress = -1f
        }
        card.addView(bg, FrameLayout.LayoutParams(-1, -1))

        val avatar = CircleIconView(ctx).apply {
            icon = d.largeIcon
            fallback = ctx.getDrawable(R.drawable.ic_person)
            discColor = pal.accent
        }
        val avatarBox = FrameLayout(ctx)
        if (s.callRingAnim.value && s.animationsOn.value) {
            avatarBox.clipChildren = false
            avatarBox.addView(
                RingView(ctx, s.callGlowColor.value),
                FrameLayout.LayoutParams((avatarSize * 2.1f).toInt(), (avatarSize * 2.1f).toInt(), Gravity.CENTER),
            )
        }
        avatarBox.addView(avatar, FrameLayout.LayoutParams(avatarSize, avatarSize, Gravity.CENTER))

        val label = mgr.text(if (d.title.isBlank()) "Incoming call" else d.title, if (large) 22f else 17f, pal.onBg, true)
        val sub = mgr.text(d.text.ifBlank { d.appName }, 14f, pal.onBgVariant, false)
        val info = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            if (large) gravity = Gravity.CENTER_HORIZONTAL
            addView(mgr.text(d.appName.uppercase(), 11f, pal.accent, true).apply { letterSpacing = 0.08f })
            addView(label)
            addView(sub)
        }

        val decline = roundButton(R.drawable.ic_call_end, s.declineColor.value, large)
        val answer = roundButton(R.drawable.ic_call, s.answerColor.value, large)
        decline.setOnClickListener { fire(d.decline, d); mgr.dismissAnimated() }
        answer.setOnClickListener { fire(d.answer, d); mgr.dismissAnimated() }
        PopupAnim.pressable(decline)
        PopupAnim.pressable(answer)

        val pad = (inset + ctx.dp(16f)).toInt()
        val content: LinearLayout
        if (large) {
            val buttons = LinearLayout(ctx).apply {
                gravity = Gravity.CENTER
                addView(decline, btnLp(true, 0))
                addView(answer, btnLp(true, 1))
            }
            content = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(pad, pad, pad, pad)
                addView(avatarBox, LinearLayout.LayoutParams((avatarSize * 2.1f).toInt(), (avatarSize * 2.1f).toInt()))
                addView(info, LinearLayout.LayoutParams(-2, -2))
                addView(buttons, LinearLayout.LayoutParams(-2, -2).apply { topMargin = ctx.dpi(16f) })
            }
        } else {
            content = LinearLayout(ctx).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(pad, (inset + ctx.dp(12f)).toInt(), pad, (inset + ctx.dp(12f)).toInt())
                addView(avatarBox, LinearLayout.LayoutParams(avatarSize, avatarSize).apply { marginEnd = ctx.dpi(12f) })
                addView(info, LinearLayout.LayoutParams(0, -2, 1f))
                addView(decline, btnLp(false, 0))
                addView(answer, btnLp(false, 1))
            }
        }
        card.addView(content, FrameLayout.LayoutParams(-1, -2))
        card.clipChildren = false

        val vGrav = when (s.callPosition.value) {
            1 -> Gravity.CENTER_VERTICAL
            2 -> Gravity.BOTTOM
            else -> Gravity.TOP
        }
        card.setOnTouchListener(
            SwipeTouchListener(
                target = card,
                dir = when (s.callPosition.value) { 2 -> 1; 1 -> 0; else -> -1 },
                onTap = { mgr.launch(d) },
                onFling = { dx, dirY -> mgr.flingAway(dx, dirY) },
                onHold = { },
            ),
        )
        mgr.attach(card, d.key, 1, 94f, 0f, vGrav)
        card.post {
            PopupAnim.enter(card, 4, 1, s.animScale(), mgr.screenW(), s.callPosition.value)
            PopupAnim.popIn(answer, s.animScale(), 200)
            PopupAnim.popIn(decline, s.animScale(), 150)
            PopupAnim.popIn(avatar, s.animScale(), 60)
            mgr.haptic()
        }
    }

    private fun btnLp(large: Boolean, idx: Int): LinearLayout.LayoutParams {
        val size = ctx.dpi(if (large) 64f else 48f)
        return LinearLayout.LayoutParams(size, size).apply {
            if (idx == 1) marginStart = ctx.dpi(if (large) 40f else 10f)
        }
    }

    private fun roundButton(icon: Int, color: Int, large: Boolean): ImageView = ImageView(ctx).apply {
        setImageResource(icon)
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        val p = ctx.dpi(if (large) 18f else 12f)
        setPadding(p, p, p, p)
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
        elevation = ctx.dp(3f)
    }

    private fun fire(pi: android.app.PendingIntent?, d: PopupData) {
        try {
            if (pi != null) pi.send() else mgr.launch(d)
        } catch (_: Exception) {
            mgr.launch(d)
        }
    }
}
