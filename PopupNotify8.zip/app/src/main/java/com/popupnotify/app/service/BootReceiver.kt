package com.popupnotify.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Brings the keep-alive service back after a reboot or an app update. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        KeepAliveService.start(context.applicationContext)
    }
}
