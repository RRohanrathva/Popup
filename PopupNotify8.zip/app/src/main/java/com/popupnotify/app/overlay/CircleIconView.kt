package com.popupnotify.app.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.drawable.Drawable
import android.view.View

/** Circular avatar / app icon. Draws a fallback glyph on a tinted disc when no icon is available. */
class CircleIconView(context: Context) : View(context) {

    var icon: Drawable? = null
    var fallback: Drawable? = null
    var discColor: Int = 0
    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        path.reset()
        path.addCircle(w / 2f, h / 2f, minOf(w, h) / 2f, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(path)
        val i = icon
        if (i != null) {
            i.setBounds(0, 0, width, height)
            i.draw(canvas)
        } else {
            canvas.drawColor(discColor)
            fallback?.let {
                val pad = (w * 0.24f).toInt()
                it.setBounds(pad, pad, width - pad, height - pad)
                it.draw(canvas)
            }
        }
        canvas.restore()
    }
}
