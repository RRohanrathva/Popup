package com.popupnotify.app.overlay

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import androidx.core.graphics.ColorUtils
import com.popupnotify.app.SettingsStore

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density
fun Context.dpi(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

class Palette(
    val bg: Int,
    val onBg: Int,
    val onBgVariant: Int,
    val accent: Int,
    val track: Int,
    val dark: Boolean,
)

fun Context.isDarkMode(): Boolean =
    (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

/** Material You colours on Android 12+, a Material 3 baseline palette below that. */
fun Context.popupPalette(opacityPct: Float): Palette {
    val dark = isDarkMode()
    val bg: Int
    val on: Int
    val onVar: Int
    val accent: Int
    if (Build.VERSION.SDK_INT >= 31) {
        bg = getColor(if (dark) android.R.color.system_neutral1_800 else android.R.color.system_neutral1_50)
        on = getColor(if (dark) android.R.color.system_neutral1_50 else android.R.color.system_neutral1_900)
        onVar = getColor(if (dark) android.R.color.system_neutral2_200 else android.R.color.system_neutral2_700)
        accent = getColor(if (dark) android.R.color.system_accent1_200 else android.R.color.system_accent1_600)
    } else {
        bg = if (dark) 0xFF2B2930.toInt() else 0xFFF3EDF7.toInt()
        on = if (dark) 0xFFE6E0E9.toInt() else 0xFF1D1B20.toInt()
        onVar = if (dark) 0xFFCAC4D0.toInt() else 0xFF49454F.toInt()
        accent = if (dark) 0xFFD0BCFF.toInt() else 0xFF6750A4.toInt()
    }
    val a = (opacityPct.coerceIn(30f, 100f) / 100f * 255f).toInt()
    return Palette(
        bg = ColorUtils.setAlphaComponent(bg, a),
        onBg = on,
        onBgVariant = onVar,
        accent = accent,
        track = ColorUtils.setAlphaComponent(on, 40),
        dark = dark,
    )
}

private val RAINBOW = intArrayOf(
    0xFFFF5C8A.toInt(), 0xFFFFB454.toInt(), 0xFF5CE1A8.toInt(),
    0xFF4DB8FF.toInt(), 0xFF9B7BFF.toInt(),
)

/** Returns a looping colour list for the sweep gradient (first colour is repeated at the end). */
fun loopColors(mode: Int, accent: Int, custom: Int): IntArray {
    val base: IntArray = when (mode) {
        1 -> RAINBOW
        else -> {
            val c = if (mode == 2) custom else accent
            val light = ColorUtils.blendARGB(c, Color.WHITE, 0.55f)
            intArrayOf(c, light, c, ColorUtils.blendARGB(c, Color.BLACK, 0.25f))
        }
    }
    return base + base[0]
}

/** Speed multiplier shared by every overlay animation. */
fun SettingsStore.animScale(): Float = if (animationsOn.value) animSpeed.value.coerceIn(0.4f, 2.5f) else 0f
