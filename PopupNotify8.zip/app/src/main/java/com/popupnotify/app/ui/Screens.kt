package com.popupnotify.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.core.graphics.drawable.toBitmap
import com.popupnotify.app.EntryStyle
import com.popupnotify.app.SettingsStore
import com.popupnotify.app.overlay.OverlayManager
import com.popupnotify.app.overlay.PopupData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val pad = Modifier.padding(horizontal = 16.dp)

@Composable
fun ScreenList(content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 8.dp, 16.dp, 120.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        content = content,
    )
}

// ---------------------------------------------------------------- Home

@Composable
fun HomeScreen(s: SettingsStore, overlay: OverlayManager, refresh: Int) {
    val ctx = LocalContext.current
    val canDraw = remember(refresh) { Settings.canDrawOverlays(ctx) }
    val listening = remember(refresh) {
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }
    ScreenList {
        item {
            SectionCard("Popup Notify") {
                SwitchRow(
                    "Floating popups", "Show every notification as a floating card",
                    s.popupEnabled.value,
                ) { s.popupEnabled.value = it }
            }
        }
        item {
            PermCard(
                "Display over other apps", "Needed to draw the popup above any screen.",
                canDraw, "Allow",
            ) {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            }
        }
        item {
            PermCard(
                "Notification access", "Needed so the app can read incoming notifications.",
                listening, "Allow",
            ) {
                ctx.startActivity(
                    Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            }
        }
        item {
            SectionCard("HyperOS setup (needed for tap & floating window)") {
                Text(
                    "1. Open permissions > Other permissions > turn ON \"Display pop-up windows while running in the background\" and \"Start in background\".\n" +
                        "2. Settings > Apps > Manage apps > Popup Notify: Autostart ON, Battery saver = No restrictions.\n" +
                        "3. For the floating window: Settings > Additional settings > Developer options > turn ON \"Enable freeform windows\" and \"Force activities to be resizable\", then restart the phone.\n" +
                        "Optional (adb): pm grant com.popupnotify.app android.permission.WRITE_SECURE_SETTINGS",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = {
                        val i = Intent("miui.intent.action.APP_PERM_EDITOR")
                            .setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
                            .putExtra("extra_pkgname", ctx.packageName)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        try { ctx.startActivity(i) } catch (_: Exception) {
                            ctx.startActivity(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            )
                        }
                    }) { Text("Permissions") }
                    FilledTonalButton(onClick = {
                        try {
                            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (_: Exception) {
                            ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                    }) { Text("Developer options") }
                }
            }
        }
        item {
            SectionCard("Try it") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { overlay.show(testData(ctx, false)) }, Modifier.weight(1f)) {
                        Icon(Icons.Filled.Notifications, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp)); Text("Notification")
                    }
                    FilledTonalButton(onClick = { overlay.show(testData(ctx, true)) }, Modifier.weight(1f)) {
                        Icon(Icons.Filled.Call, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp)); Text("Call")
                    }
                }
            }
        }
    }
}

@Composable
private fun PermCard(title: String, body: String, ok: Boolean, action: String, onClick: () -> Unit) {
    val container by animateColorAsState(
        if (ok) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer,
        label = "perm",
    )
    Surface(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(32.dp), color = container,
    ) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (ok) Icons.Filled.CheckCircle else Icons.Filled.Warning, null, Modifier.size(32.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(if (ok) "Granted" else body, style = MaterialTheme.typography.bodyMedium)
            }
            if (!ok) Button(onClick = onClick) { Text(action) }
        }
    }
}

private fun testData(ctx: Context, call: Boolean): PopupData {
    val icon = try { ctx.packageManager.getApplicationIcon(ctx.packageName) } catch (_: Exception) { null }
    return PopupData(
        key = "test", pkg = ctx.packageName, appName = if (call) "Phone" else "Messages",
        title = "John Smith",
        text = if (call) "Incoming call" else "What day did you want to do lunch?",
        appIcon = icon, largeIcon = null, contentIntent = null,
        isCall = call, answer = null, decline = null,
        actions = if (call) emptyList() else listOf(
            com.popupnotify.app.overlay.PopupAction("Mark as read", null, null, emptyList(), false),
            com.popupnotify.app.overlay.PopupAction(
                "Reply", null, null, listOf("Whenever you want", "I don't know", "Any time"), true,
            ),
        ),
    )
}

// ---------------------------------------------------------------- Popup customisation

@Composable
fun PopupScreen(s: SettingsStore, overlay: OverlayManager) {
    val ctx = LocalContext.current
    ScreenList {
        item {
            SectionCard("Timing & shape") {
                SliderRow("Stay on screen", s.durationSec.value, 2f..15f, " s", 0) { s.durationSec.value = it }
                SliderRow("Corner radius", s.corner.value, 8f..40f, " dp") { s.corner.value = it }
                SliderRow("Width", s.widthPct.value, 60f..100f, "%") { s.widthPct.value = it }
                SliderRow("Background opacity", s.bgOpacity.value, 40f..100f, "%") { s.bgOpacity.value = it }
                SwitchRow("Countdown line", "Thin progress line at the bottom", s.showProgress.value) { s.showProgress.value = it }
                SwitchRow("Haptic tick", null, s.haptic.value) { s.haptic.value = it }
                SwitchRow("Hide ongoing notifications", "Music players, downloads and similar", s.ignoreOngoing.value) { s.ignoreOngoing.value = it }
            }
        }
        item {
            SectionCard("Content & gesture") {
                SwitchRow("Action buttons", "Mark as read, Reply and other buttons of the app", s.showActions.value) { s.showActions.value = it }
                SwitchRow("Quick reply chips", "Shown when the app offers smart replies", s.showChips.value) { s.showChips.value = it }
                SwitchRow("Floating window gesture", "Pull the bottom handle down to open the app in a floating window", s.floatGesture.value) { s.floatGesture.value = it }
                SwitchRow("Show handle", null, s.showHandle.value) { s.showHandle.value = it }
            }
        }
        item {
            SectionCard("HyperOS style behaviour") {
                ChoiceRow(
                    "After swiping a popup up, hide the next ones",
                    com.popupnotify.app.HideRule.names,
                    s.hideRule.value,
                ) { s.hideRule.value = it }
                Text(
                    "Pull the handle at the bottom of a popup down to open the app in a floating window.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        item {
            SectionCard("Messages") {
                ChoiceRow(
                    "When a new notification comes",
                    listOf("Only the new one", "With earlier messages"),
                    s.historyMode.value,
                ) { s.historyMode.value = it }
                SwitchRow("Layered stack", "Many notifications pile up in layers. Swipe the top one away to see the next one", s.stackOn.value) { s.stackOn.value = it }
            }
        }
        item {
            SectionCard("Position") {
                ChoiceRow("Screen position", listOf("Top", "Middle", "Bottom"), s.popupV.value) { s.popupV.value = it }
                ChoiceRow("Horizontal", listOf("Left", "Center", "Right"), s.position.value) { s.position.value = it }
                SliderRow("Distance from edge", s.topOffset.value, 0f..120f, " dp") { s.topOffset.value = it }
            }
        }
        item {
            SectionCard("Animation") {
                SwitchRow("Animations", "Turn all popup animations on or off", s.animationsOn.value) { s.animationsOn.value = it }
                ChoiceRow("Entry style", EntryStyle.names, s.entryAnim.value) { s.entryAnim.value = it }
                SliderRow("Speed", s.animSpeed.value, 0.5f..2f, "x", 1) { s.animSpeed.value = it }
                ChoiceRow("Motion curve (HyperOS style engine)", com.popupnotify.app.MotionCurve.names, s.animCurve.value) { s.animCurve.value = it }
                SliderRow("Response (smaller = snappier)", s.springResponse.value, 0.15f..0.8f, " s", 2) { s.springResponse.value = it }
                if (s.animCurve.value == 0) {
                    SliderRow("Damping (1 = no bounce)", s.springDamping.value, 0.3f..1f, "", 2) { s.springDamping.value = it }
                }
            }
        }
        item {
            SectionCard("Glow border") {
                SwitchRow("Glow animation", "Rotating light around the popup", s.glowOn.value) { s.glowOn.value = it }
                ChoiceRow("Colour mode", listOf("Theme", "Rainbow", "Custom"), s.glowMode.value) { s.glowMode.value = it }
                if (s.glowMode.value == 2) ColorRow("Glow colour", s.glowColor.value) { s.glowColor.value = it }
                SliderRow("Glow speed", s.glowSpeed.value, 1f..10f, "", 0) { s.glowSpeed.value = it }
                SliderRow("Glow thickness", s.glowWidth.value, 1f..6f, " dp", 1) { s.glowWidth.value = it }
                SliderRow("Glow brightness", s.glowIntensity.value, 20f..100f, "%") { s.glowIntensity.value = it }
            }
        }
        item {
            Button(onClick = { overlay.show(testData(ctx, false)) }, Modifier.fillMaxWidth().height(56.dp)) {
                Text("Preview popup")
            }
        }
    }
}

// ---------------------------------------------------------------- Call customisation

@Composable
fun CallScreen(s: SettingsStore, overlay: OverlayManager) {
    val ctx = LocalContext.current
    ScreenList {
        item {
            SectionCard("Call popup") {
                SwitchRow("Separate call popup", "Calls get their own style", s.callEnabled.value) { s.callEnabled.value = it }
                ChoiceRow("Layout", listOf("Compact", "Large"), s.callStyle.value) { s.callStyle.value = it }
                ChoiceRow("Screen position", listOf("Top", "Center", "Bottom"), s.callPosition.value) { s.callPosition.value = it }
                SliderRow("Corner radius", s.callCorner.value, 12f..44f, " dp") { s.callCorner.value = it }
            }
        }
        item {
            SectionCard("Call animation") {
                SwitchRow("Ringing pulse", "Expanding rings around the caller", s.callRingAnim.value) { s.callRingAnim.value = it }
                SwitchRow("Glow border", null, s.callGlowOn.value) { s.callGlowOn.value = it }
                ColorRow("Glow & ring colour", s.callGlowColor.value) { s.callGlowColor.value = it }
                SliderRow("Glow speed", s.callGlowSpeed.value, 1f..10f, "", 0) { s.callGlowSpeed.value = it }
            }
        }
        item {
            SectionCard("Buttons") {
                ColorRow("Answer", s.answerColor.value) { s.answerColor.value = it }
                ColorRow("Decline", s.declineColor.value) { s.declineColor.value = it }
            }
        }
        item {
            Button(onClick = { overlay.show(testData(ctx, true)) }, Modifier.fillMaxWidth().height(56.dp)) {
                Text("Preview call popup")
            }
        }
    }
}

// ---------------------------------------------------------------- Per-app switches

private class AppItem(val pkg: String, val label: String, val icon: androidx.compose.ui.graphics.ImageBitmap)

@Composable
fun AppsScreen(s: SettingsStore) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppItem>?>(null) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.Default) {
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(i, 0)
                .filter { it.activityInfo.packageName != ctx.packageName }
                .map {
                    AppItem(
                        it.activityInfo.packageName,
                        it.loadLabel(pm).toString(),
                        it.loadIcon(pm).toBitmap(96, 96).asImageBitmap(),
                    )
                }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
        }
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            label = { Text("Search apps") }, singleLine = true,
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth().padding(16.dp, 4.dp, 16.dp, 8.dp),
        )
        val list = apps?.filter { it.label.contains(query, ignoreCase = true) }
        if (list == null) {
            Text("Loading apps...", modifier = pad, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            LazyColumn(
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 0.dp, 16.dp, 120.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                items(list, key = { it.pkg }) { a ->
                    val blocked = a.pkg in s.blocked
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        modifier = Modifier.fillMaxWidth().clickable { s.setBlocked(a.pkg, !blocked) },
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Image(a.icon, null, Modifier.size(42.dp))
                            Spacer(Modifier.width(14.dp))
                            Text(a.label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                            androidx.compose.material3.Switch(checked = !blocked, onCheckedChange = { s.setBlocked(a.pkg, !it) })
                        }
                    }
                }
            }
        }
    }
}
