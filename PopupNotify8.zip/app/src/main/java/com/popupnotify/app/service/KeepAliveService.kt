package com.popupnotify.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.popupnotify.app.MainActivity

/**
 * Keeps the app process alive (foreground service with a quiet, minimised notification) so the
 * system / HyperOS does not kill the notification listener when the app is closed or swiped away.
 */
class KeepAliveService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Popup Notify running", NotificationManager.IMPORTANCE_MIN).apply {
                    setShowBadge(false)
                    description = "Keeps Popup Notify running in the background"
                },
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(com.popupnotify.app.R.drawable.ic_call)
            .setContentTitle("Popup Notify is running")
            .setContentText("Popups are active")
            .setOngoing(true)
            .setContentIntent(open)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(ID, n)
            }
        } catch (_: Throwable) {
        }
    }

    companion object {
        private const val CHANNEL = "keep_alive"
        private const val ID = 4242

        /** Starts the service, only when notification access is granted. Never throws. */
        fun start(ctx: Context) {
            try {
                if (!NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)) return
                ContextCompat.startForegroundService(ctx, Intent(ctx, KeepAliveService::class.java))
            } catch (_: Throwable) {
            }
        }
    }
}
