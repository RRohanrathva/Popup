package com.popupnotify.app.overlay

import android.animation.LayoutTransition
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import com.popupnotify.app.R
import com.popupnotify.app.SettingsStore
import kotlin.math.max

internal class KeyFrame(ctx: Context, private val onBack: () -> Unit) : FrameLayout(ctx) {
    private var dx0 = 0f
    private var dy0 = 0f
    private val slop = android.view.ViewConfiguration.get(ctx).scaledTouchSlop * 2

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_BACK && e.action == KeyEvent.ACTION_UP) {
            onBack()
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    /** Lets a swipe that starts on a button still move the whole card. */
    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dx0 = e.rawX; dy0 = e.rawY }
            MotionEvent.ACTION_MOVE ->
                if (kotlin.math.abs(e.rawX - dx0) > slop || kotlin.math.abs(e.rawY - dy0) > slop) return true
        }
        return false
    }
}

/**
 * Pixel / Android 16 style heads-up card: avatar, "Name . now", message, smart-reply chips,
 * text actions (Mark as read, Reply) and a handle at the bottom. Pull the handle down to open the
 * app in a floating window.
 */
class NotificationCard(
    private val ctx: Context,
    private val s: SettingsStore,
    private val mgr: OverlayManager,
) {
    private var replying = false

    fun build(d: PopupData) {
        val pal = ctx.popupPalette(s.bgOpacity.value)
        val corner = ctx.dp(s.corner.value)
        val inset = ctx.dp(if (s.glowOn.value) 9f else 6f)

        val vert = s.popupV.value
        val depth = mgr.stackDepth
        val layerStep = ctx.dpi(9f)
        val extra = depth * layerStep
        val card = KeyFrame(ctx) { mgr.dismissAnimated() }
        val peeks = mutableListOf<View>()
        for (i in depth downTo 1) {
            val peek = View(ctx).apply {
                background = GradientDrawable().apply {
                    cornerRadius = corner * 0.9f
                    setColor(ColorUtils.blendARGB(pal.bg, pal.onBg, 0.07f * i))
                }
            }
            peeks.add(peek)
            val side = (inset + ctx.dp(10f * i)).toInt()
            card.addView(
                peek,
                FrameLayout.LayoutParams(-1, ctx.dpi(44f), Gravity.BOTTOM).apply {
                    leftMargin = side
                    rightMargin = side
                    bottomMargin = extra - i * layerStep
                },
            )
        }
        val bg = GlowBackgroundView(ctx).apply {
            cornerPx = corner
            this.inset = inset
            fillColor = pal.bg
            glowEnabled = s.glowOn.value
            glowColors = loopColors(s.glowMode.value, pal.accent, s.glowColor.value)
            glowStrokePx = ctx.dp(s.glowWidth.value)
            glowIntensity = s.glowIntensity.value / 100f
            glowSpeed = if (s.animationsOn.value) s.glowSpeed.value * s.animSpeed.value else 0f
            progressColor = pal.accent
            trackColor = pal.track
            progress = if (s.showProgress.value) 1f else -1f
        }
        card.addView(bg, FrameLayout.LayoutParams(-1, -1).apply { bottomMargin = extra })

        // ---- avatar with small app badge
        val avatarSize = ctx.dpi(40f)
        val iconView = CircleIconView(ctx).apply {
            icon = d.largeIcon ?: d.appIcon
            fallback = ctx.getDrawable(R.drawable.ic_person)
            discColor = pal.accent
        }
        val badgeView = CircleIconView(ctx).apply {
            icon = d.appIcon
            discColor = pal.accent
        }
        val iconBox = FrameLayout(ctx).apply {
            addView(iconView, FrameLayout.LayoutParams(avatarSize, avatarSize))
            if (d.largeIcon != null && d.appIcon != null) {
                addView(badgeView, FrameLayout.LayoutParams(ctx.dpi(18f), ctx.dpi(18f), Gravity.END or Gravity.BOTTOM))
            }
        }

        // ---- header + body
        val name = d.title.ifBlank { d.appName }
        val sb = SpannableStringBuilder(name)
        sb.setSpan(StyleSpan(Typeface.BOLD), 0, name.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(ForegroundColorSpan(pal.onBg), 0, name.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val start = sb.length
        sb.append("  ·  now")
        sb.setSpan(ForegroundColorSpan(pal.onBgVariant), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val header = TextView(ctx).apply {
            text = sb
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val body = mgr.text(d.text, 14f, pal.onBgVariant, false).apply {
            maxLines = 2
            visibility = if (d.text.isBlank()) View.GONE else View.VISIBLE
        }
        val textCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(header)
            d.history.forEach { line ->
                addView(
                    mgr.text(line, 13f, ColorUtils.setAlphaComponent(pal.onBgVariant, 190), false),
                    LinearLayout.LayoutParams(-1, -2).apply { topMargin = ctx.dpi(1f) },
                )
            }
            addView(body)
        }

        val chevron = ImageView(ctx).apply {
            setImageResource(R.drawable.ic_expand_more)
            setColorFilter(pal.onBgVariant)
            val p = ctx.dpi(2f)
            setPadding(p, p, p, p)
        }
        var expanded = false
        chevron.setOnClickListener {
            expanded = !expanded
            body.maxLines = if (expanded) 8 else 2
            chevron.animate().rotation(if (expanded) 180f else 0f).setDuration(260)
                .setInterpolator(OvershootInterpolator(1.8f)).start()
        }
        PopupAnim.pressable(chevron)

        val topRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(iconBox, LinearLayout.LayoutParams(avatarSize, avatarSize).apply { marginEnd = ctx.dpi(12f) })
            addView(textCol, LinearLayout.LayoutParams(0, -2, 1f))
            addView(chevron, LinearLayout.LayoutParams(ctx.dpi(28f), ctx.dpi(28f)).apply { marginStart = ctx.dpi(6f) })
        }

        val indent = avatarSize + ctx.dpi(12f)

        // ---- smart reply chips (only when the app provides fixed choices)
        val choiceMap = LinkedHashMap<String, PopupAction>()
        if (s.showChips.value) {
            d.actions.forEach { a ->
                a.choices.forEach { c -> if (choiceMap.size < 3 && !choiceMap.containsKey(c)) choiceMap[c] = a }
            }
        }
        val chipsRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            choiceMap.forEach { (label, action) ->
                addView(
                    chip(label, pal) { mgr.sendReply(action, label); mgr.dismissAnimated() },
                    LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = ctx.dpi(8f) },
                )
            }
        }

        // ---- text actions: Mark as read, Reply ...
        val buttons = if (s.showActions.value) d.actions.filter { !it.choicesOnly }.take(3) else emptyList()
        val actionsRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }

        // ---- inline reply box (hidden until Reply is tapped)
        val edit = EditText(ctx).apply {
            hint = "Reply to $name"
            setHintTextColor(pal.onBgVariant)
            setTextColor(pal.onBg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            setSingleLine(true)
            setPadding(ctx.dpi(16f), ctx.dpi(10f), ctx.dpi(16f), ctx.dpi(10f))
            background = GradientDrawable().apply {
                cornerRadius = ctx.dp(24f)
                setColor(ColorUtils.setAlphaComponent(pal.onBg, 28))
            }
        }
        val send = ImageView(ctx).apply {
            setImageResource(R.drawable.ic_send)
            val p = ctx.dpi(10f)
            setPadding(p, p, p, p)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(pal.accent) }
        }
        PopupAnim.pressable(send)
        val replyRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            addView(edit, LinearLayout.LayoutParams(0, -2, 1f))
            addView(send, LinearLayout.LayoutParams(ctx.dpi(42f), ctx.dpi(42f)).apply { marginStart = ctx.dpi(8f) })
        }

        var replyAction: PopupAction? = null
        fun doSend() {
            val t = edit.text.toString().trim()
            if (t.isEmpty()) return
            replyAction?.let { mgr.sendReply(it, t) }
            (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(edit.windowToken, 0)
            mgr.dismissAnimated()
        }
        send.setOnClickListener { doSend() }
        edit.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) { doSend(); true } else false
        }

        fun showReply(a: PopupAction) {
            replying = true
            replyAction = a
            mgr.stopTimer()
            chipsRow.visibility = View.GONE
            actionsRow.visibility = View.GONE
            replyRow.visibility = View.VISIBLE
            mgr.setFocusable(true)
            edit.requestFocus()
            edit.postDelayed({
                (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showSoftInput(edit, InputMethodManager.SHOW_IMPLICIT)
            }, 150)
        }

        buttons.forEach { a ->
            val tv = TextView(ctx).apply {
                text = a.title
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTextColor(pal.accent)
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                maxLines = 1
                setPadding(ctx.dpi(4f), ctx.dpi(10f), ctx.dpi(18f), ctx.dpi(10f))
                setOnClickListener {
                    if (a.isReply) showReply(a) else { mgr.fire(a.intent); mgr.dismissAnimated() }
                }
            }
            PopupAnim.pressable(tv)
            actionsRow.addView(tv)
        }

        // ---- bottom handle: pull down to open in a floating window
        val pillBg = GradientDrawable().apply {
            cornerRadius = ctx.dp(3f)
            setColor(ColorUtils.setAlphaComponent(pal.onBgVariant, 110))
        }
        val pill = View(ctx).apply { background = pillBg }
        val handleBox = FrameLayout(ctx).apply {
            addView(pill, FrameLayout.LayoutParams(ctx.dpi(40f), ctx.dpi(4f), Gravity.CENTER))
        }
        val handleOn = s.showHandle.value && s.floatGesture.value
        installHandleGesture(handleBox, pill, pillBg, card, pal, d)

        // ---- assemble
        val padH = (inset + ctx.dp(16f)).toInt()
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padH, (inset + ctx.dp(14f)).toInt(), padH, (inset + ctx.dp(2f)).toInt())
            layoutTransition = LayoutTransition().apply {
                enableTransitionType(LayoutTransition.CHANGING)
                setDuration(240)
            }
            addView(topRow)
            if (choiceMap.isNotEmpty()) {
                addView(chipsRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ctx.dpi(12f); marginStart = indent })
            }
            if (buttons.isNotEmpty()) {
                addView(actionsRow, LinearLayout.LayoutParams(-2, -2).apply { topMargin = ctx.dpi(4f); marginStart = indent })
            }
            addView(replyRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ctx.dpi(10f); marginStart = indent })
            addView(
                handleBox,
                LinearLayout.LayoutParams(-1, ctx.dpi(if (handleOn) 26f else 8f)),
            )
        }
        if (!handleOn) handleBox.visibility = View.INVISIBLE
        card.addView(col, FrameLayout.LayoutParams(-1, -2).apply { bottomMargin = extra })

        card.setOnTouchListener(
            SwipeTouchListener(
                target = card,
                dir = when (vert) { 2 -> 1; 1 -> 0; else -> -1 },
                onTap = { mgr.launch(d); mgr.dismissAnimated() },
                onFling = { dx, dirY -> mgr.flingAway(dx, dirY) },
                onHold = { held -> mgr.holdTimer(held) },
                onOutside = { if (replying) mgr.dismissAnimated() },
            ),
        )

        val vGrav = when (vert) { 2 -> Gravity.BOTTOM; 1 -> Gravity.CENTER_VERTICAL; else -> Gravity.TOP }
        mgr.attach(card, d.key, s.position.value, s.widthPct.value, s.topOffset.value, vGrav)
        card.post {
            val k = s.animScale()
            PopupAnim.enter(card, s.entryAnim.value, s.position.value, k, mgr.screenW(), vert)
            peeks.forEachIndexed { i, pv -> PopupAnim.tuckIn(pv, i, k) }
            val parts = mutableListOf<View>(iconBox, textCol)
            if (choiceMap.isNotEmpty()) parts.add(chipsRow)
            if (buttons.isNotEmpty()) parts.add(actionsRow)
            PopupAnim.stagger(parts, k)
            PopupAnim.popIn(iconBox, k)
            for (i in 0 until chipsRow.childCount) PopupAnim.popIn(chipsRow.getChildAt(i), k, 230L + i * 70L)
            mgr.haptic()
            mgr.startTimer(bg, s.durationSec.value)
        }
    }

    private fun chip(label: String, pal: Palette, onClick: () -> Unit): TextView = TextView(ctx).apply {
        text = label
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        setTextColor(pal.onBg)
        gravity = Gravity.CENTER
        maxLines = 2
        ellipsize = TextUtils.TruncateAt.END
        setPadding(ctx.dpi(10f), ctx.dpi(9f), ctx.dpi(10f), ctx.dpi(9f))
        background = GradientDrawable().apply {
            cornerRadius = ctx.dp(16f)
            setColor(Color.TRANSPARENT)
            setStroke(ctx.dpi(1f), ColorUtils.setAlphaComponent(pal.onBgVariant, 150))
        }
        setOnClickListener { onClick() }
        PopupAnim.pressable(this)
    }

    private fun installHandleGesture(
        handle: View,
        pill: View,
        pillBg: GradientDrawable,
        card: View,
        pal: Palette,
        d: PopupData,
    ) {
        val threshold = ctx.dp(54f)
        var startY = 0f
        var passed = false
        handle.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startY = e.rawY
                    passed = false
                    mgr.holdTimer(true)
                    PopupAnim.cancelSprings(card)
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    pill.animate().scaleX(1.35f).setDuration(120).start()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val pulled = max(0f, e.rawY - startY) * 0.6f
                    card.translationY = pulled
                    val p = (pulled / threshold).coerceIn(0f, 1f)
                    card.scaleX = 1f - 0.05f * p
                    card.scaleY = 1f - 0.05f * p
                    if (!passed && pulled >= threshold) {
                        passed = true
                        pillBg.setColor(pal.accent)
                        pill.animate().scaleX(1.9f).setDuration(140).start()
                        mgr.haptic()
                    } else if (passed && pulled < threshold) {
                        passed = false
                        pillBg.setColor(ColorUtils.setAlphaComponent(pal.onBgVariant, 110))
                        pill.animate().scaleX(1.35f).setDuration(140).start()
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (passed && e.actionMasked == MotionEvent.ACTION_UP) {
                        mgr.stopTimer()
                        mgr.launchFloating(d)
                        card.pivotY = card.height.toFloat()
                        card.animate().scaleX(0.5f).scaleY(0.5f).alpha(0f)
                            .translationY(card.translationY + ctx.dp(70f))
                            .setDuration(260).setInterpolator(AccelerateInterpolator(1.4f))
                            .withEndAction { mgr.dismissNow() }.start()
                    } else {
                        card.animate().translationY(0f).scaleX(1f).scaleY(1f).setDuration(300)
                            .setInterpolator(OvershootInterpolator(1.6f)).start()
                        pill.animate().scaleX(1f).setDuration(160).start()
                        pillBg.setColor(ColorUtils.setAlphaComponent(pal.onBgVariant, 110))
                        mgr.holdTimer(false)
                    }
                    true
                }
                else -> false
            }
        }
    }
}
