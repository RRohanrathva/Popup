package com.popupnotify.app.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.popupnotify.app.SettingsStore

/** Owns the single on-screen popup (notification or call) and everything that animates inside it. */
class OverlayManager(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val settings = SettingsStore.get(ctx)
    private val main = Handler(Looper.getMainLooper())

    private var root: View? = null
    private var currentKey: String? = null
    private var timer: ValueAnimator? = null
    private var glow: GlowBackgroundView? = null
    private var closing = false
    private var curVert = 0
    internal var stackDepth = 0

    fun canDraw(): Boolean = Settings.canDrawOverlays(ctx)

    fun show(data: PopupData) {
        if (!canDraw()) return
        main.post {
            val keep = settings.stackOn.value && root != null && !data.isCall && !closing
            val depth = if (keep) minOf(2, stackDepth + 1) else 0
            removeCurrent()
            stackDepth = depth
            if (data.isCall) showCall(data) else showNotification(data)
        }
    }

    fun dismissKey(key: String) {
        main.post { if (currentKey == key) dismissAnimated() }
    }

    fun destroy() {
        main.post { dismissNow() }
    }

    // ------------------------------------------------------------------ notification card

    private fun showNotification(d: PopupData) {
        NotificationCard(ctx, settings, this).build(d)
    }

    // ------------------------------------------------------------------ call card

    private fun showCall(d: PopupData) {
        CallPopup(ctx, settings, this).build(d)
    }

    // ------------------------------------------------------------------ shared plumbing

    internal fun attach(
        view: View,
        key: String,
        gravityH: Int,
        widthPct: Float,
        topDp: Float,
        vGravity: Int,
    ) {
        val w = (screenW() * widthPct.coerceIn(60f, 100f) / 100f).toInt()
        val lp = WindowManager.LayoutParams(
            w,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT,
        )
        val h = when (gravityH) {
            0 -> Gravity.START
            2 -> Gravity.END
            else -> Gravity.CENTER_HORIZONTAL
        }
        lp.gravity = vGravity or h
        val status = statusBarHeight()
        lp.y = if (vGravity == Gravity.TOP) (status + ctx.dp(topDp)).toInt() else if (vGravity == Gravity.BOTTOM) ctx.dpi(topDp + 24f) else 0
        lp.x = if (gravityH == 1) 0 else ctx.dpi(((100f - widthPct.coerceIn(60f, 100f)) / 2f).coerceAtMost(4f))
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        lp.windowAnimations = 0
        try {
            wm.addView(view, lp)
            root = view
            curVert = when (vGravity) { Gravity.BOTTOM -> 2; Gravity.CENTER_VERTICAL -> 1; else -> 0 }
            currentKey = key
            closing = false
        } catch (_: Exception) {
            root = null
        }
    }

    internal fun startTimer(bg: GlowBackgroundView?, seconds: Float) {
        timer?.cancel()
        if (seconds <= 0f) return
        timer = ValueAnimator.ofFloat(1f, 0f).apply {
            duration = (seconds * 1000).toLong()
            interpolator = LinearInterpolator()
            addUpdateListener { if (settings.showProgress.value) bg?.progress = it.animatedValue as Float }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                var cancelled = false
                override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(a: android.animation.Animator) { if (!cancelled) dismissAnimated() }
            })
            start()
        }
    }

    internal fun haptic() {
        if (!settings.haptic.value) return
        try {
            val vib = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 29) vib.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
            else vib.vibrate(VibrationEffect.createOneShot(12, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {
        }
    }

    internal fun launch(d: PopupData) {
        try {
            d.contentIntent?.send()
        } catch (_: Exception) {
            ctx.packageManager.getLaunchIntentForPackage(d.pkg)?.let {
                it.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(it)
            }
        }
    }

    internal fun flingAway(dx: Float, dirY: Float) {
        val v = root ?: return
        timer?.cancel()
        val a = v.animate().alpha(0f).setDuration(200)
        if (dirY == 0f) a.translationX(if (dx > 0) screenW().toFloat() else -screenW().toFloat())
        else a.translationY(dirY * (v.height.toFloat() + 80f))
        a.withEndAction { dismissNow() }.start()
    }

    internal fun holdTimer(held: Boolean) {
        if (held) timer?.pause() else timer?.resume()
    }

    internal fun stopTimer() {
        timer?.cancel()
    }

    /** Lets the popup take keyboard focus (needed for the inline reply box). */
    internal fun setFocusable(on: Boolean) {
        val v = root ?: return
        val lp = v.layoutParams as? WindowManager.LayoutParams ?: return
        lp.flags = if (on) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
    }

    internal fun sendReply(a: PopupAction, text: String) {
        val ri = a.remoteInputs ?: return
        try {
            val intent = android.content.Intent().addFlags(android.content.Intent.FLAG_RECEIVER_FOREGROUND)
            val bundle = android.os.Bundle()
            ri.forEach { bundle.putCharSequence(it.resultKey, text) }
            android.app.RemoteInput.addResultsToIntent(ri, intent, bundle)
            a.intent?.send(ctx, 0, intent)
        } catch (_: Exception) {
        }
    }

    internal fun fire(pi: android.app.PendingIntent?) {
        try { pi?.send() } catch (_: Exception) {}
    }

    /** Opens the notification's app in a floating (freeform) window. Falls back to a normal launch. */
    internal fun launchFloating(d: PopupData) {
        try {
            val dm = ctx.resources.displayMetrics
            val w = (dm.widthPixels * 0.84f).toInt()
            val h = (dm.heightPixels * 0.58f).toInt()
            val l = (dm.widthPixels - w) / 2
            val t = (dm.heightPixels * 0.2f).toInt()
            val opts = android.app.ActivityOptions.makeBasic()
            opts.setLaunchBounds(android.graphics.Rect(l, t, l + w, t + h))
            try {
                // 5 = WINDOWING_MODE_FREEFORM. Hidden API: ignored on systems that block it.
                android.app.ActivityOptions::class.java
                    .getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType)
                    .invoke(opts, 5)
            } catch (_: Throwable) {
            }
            if (Build.VERSION.SDK_INT >= 34) {
                opts.setPendingIntentBackgroundActivityStartMode(
                    android.app.ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED,
                )
            }
            val bundle = opts.toBundle()
            val pi = d.contentIntent
            if (pi != null) {
                pi.send(ctx, 0, null, null, null, null, bundle)
            } else {
                val i = ctx.packageManager.getLaunchIntentForPackage(d.pkg) ?: return
                i.addFlags(
                    android.content.Intent.FLAG_ACTIVITY_NEW_TASK or
                        android.content.Intent.FLAG_ACTIVITY_MULTIPLE_TASK,
                )
                ctx.startActivity(i, bundle)
            }
        } catch (_: Exception) {
            launch(d)
        }
    }

    internal fun dismissAnimated() {
        val v = root ?: return
        if (closing) return
        closing = true
        timer?.cancel()
        val st = settings
        PopupAnim.exit(v, st.entryAnim.value, st.position.value, st.animScale(), screenW(), curVert) { dismissNow() }
    }

    internal fun dismissNow() {
        removeCurrent()
        stackDepth = 0
    }

    private fun removeCurrent() {
        timer?.cancel()
        timer = null
        root?.let {
            PopupAnim.cancelSprings(it)
            try { wm.removeViewImmediate(it) } catch (_: Exception) {}
        }
        root = null
        currentKey = null
        glow = null
        closing = false
    }

    internal fun screenW(): Int = ctx.resources.displayMetrics.widthPixels

    private fun statusBarHeight(): Int {
        val id = ctx.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else ctx.dpi(24f)
    }

    internal fun text(t: String, sp: Float, color: Int, bold: Boolean): TextView = TextView(ctx).apply {
        text = t
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
}
