package com.popupnotify.app.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.popupnotify.app.SettingsStore

/** Owns the single on-screen popup (notification or call) and everything that animates inside it. */
class OverlayManager(private val ctx: Context) {

    private companion object { const val MAX_STACK = 6 }

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val settings = SettingsStore.get(ctx)
    private val main = Handler(Looper.getMainLooper())

    private var root: View? = null      // window root (transparent holder)
    private var card: View? = null      // the visible card: every animation runs on this view
    private var currentKey: String? = null
    private var timer: ValueAnimator? = null
    private var glow: GlowBackgroundView? = null
    private var closing = false
    private var curVert = 0
    // Layered stack: last item is the card on top. Older notifications sit underneath it.
    private val stack = ArrayList<PopupData>()
    private var group: FrameLayout? = null
    private var peekViews: MutableList<View> = mutableListOf()
    private var callShowing = false
    private var reuse = false
    internal var promoting = false
    internal val stackDepth: Int
        get() = if (settings.stackOn.value && !callShowing) minOf(2, maxOf(0, stack.size - 1)) else 0
    private var topInsetBase = 0
    private var baseSlackBottom = 0

    init {
        // Needed to reach ActivityOptions.setLaunchWindowingMode (floating window).
        if (Build.VERSION.SDK_INT >= 28) {
            try { org.lsposed.hiddenapibypass.HiddenApiBypass.addHiddenApiExemptions("L") } catch (_: Throwable) {}
        }
    }

    fun canDraw(): Boolean = Settings.canDrawOverlays(ctx)

    fun show(data: PopupData) {
        if (!canDraw()) return
        main.post {
            if (data.isCall) {
                stack.clear()
                removeCurrent()
                callShowing = true
                showCall(data)
                return@post
            }
            if (callShowing && root != null) return@post   // never cover a ringing call
            val live = root != null && !closing && settings.stackOn.value
            if (live) {
                stack.removeAll { it.key == data.key }
                stack.add(data)
                while (stack.size > MAX_STACK) stack.removeAt(0)
                reuse = true
                showNotification(data)
            } else {
                stack.clear()
                stack.add(data)
                removeCurrent()
                showNotification(data)
            }
        }
    }

    fun dismissKey(key: String) {
        main.post {
            if (currentKey == key) dismissAnimated()
            else if (stack.removeAll { it.key == key }) refreshStackLook()
        }
    }

    fun destroy() {
        main.post { dismissNow() }
    }

    // ------------------------------------------------------------------ notification card

    private fun showNotification(d: PopupData) {
        NotificationCard(ctx, settings, this).build(d)
    }

    // ------------------------------------------------------------------ call card

    private fun showCall(d: PopupData) {
        CallPopup(ctx, settings, this).build(d)
    }

    // ------------------------------------------------------------------ shared plumbing

    internal fun attach(
        view: View,
        key: String,
        gravityH: Int,
        widthPct: Float,
        topDp: Float,
        vGravity: Int,
        peeks: List<View> = emptyList(),
        extra: Int = 0,
    ) {
        val grp0 = group
        if (reuse && root != null && grp0 != null) {
            reuse = false
            swapCard(grp0, view, key, vGravity, peeks, extra)
            return
        }
        reuse = false
        val sw = screenW()
        val w = (sw * widthPct.coerceIn(60f, 100f) / 100f).toInt()
        // The window is only as big as its content, so anything that moves the card inside it
        // (slide in / out, swipe, pull) gets clipped at the window edge, which showed up as the
        // card being cut off and ghosting over the status bar. The card therefore sits inside a
        // transparent holder with spare room on the side it travels towards. The spare room is
        // placed off-screen (window y may be negative with FLAG_LAYOUT_NO_LIMITS).
        val full = widthPct >= 85f
        val sideX = ctx.dpi(((100f - widthPct.coerceIn(60f, 100f)) / 2f).coerceAtMost(4f))
        val slackBig = ctx.dpi(220f)
        val slackMid = ctx.dpi(30f)
        val slackTop = when (vGravity) { Gravity.TOP -> slackBig; Gravity.CENTER_VERTICAL -> slackMid; else -> 0 }
        val slackBottom = when (vGravity) { Gravity.BOTTOM -> slackBig; Gravity.CENTER_VERTICAL -> slackMid; else -> 0 }

        val holder = FrameLayout(ctx)
        holder.clipChildren = false
        holder.clipToPadding = false
        val clp = FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT)
        clp.topMargin = slackTop
        clp.bottomMargin = slackBottom
        if (full) {
            clp.gravity = when (gravityH) {
                0 -> Gravity.START
                2 -> Gravity.END
                else -> Gravity.CENTER_HORIZONTAL
            }
            if (gravityH == 0) clp.leftMargin = sideX
            if (gravityH == 2) clp.rightMargin = sideX
        }
        baseSlackBottom = slackBottom
        // The group holds the layers peeking out underneath plus the card on top. Only the card
        // is animated or swiped, so the layers underneath stay in place when the top one leaves.
        val grp = FrameLayout(ctx)
        grp.clipChildren = false
        grp.clipToPadding = false
        peeks.forEach { grp.addView(it) }
        view.alpha = 0f // hidden until the entry animation starts, so it never flashes in place
        grp.addView(view, FrameLayout.LayoutParams(-1, -2).apply { bottomMargin = extra })
        holder.addView(grp, clp)
        group = grp
        peekViews = peeks.toMutableList()
        holder.setOnTouchListener { _, e ->
            if (e.actionMasked == android.view.MotionEvent.ACTION_OUTSIDE) card?.dispatchTouchEvent(e)
            false
        }

        val lp = WindowManager.LayoutParams(
            if (full) sw else w,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT,
        )
        val h = if (full) Gravity.START else when (gravityH) {
            0 -> Gravity.START
            2 -> Gravity.END
            else -> Gravity.CENTER_HORIZONTAL
        }
        lp.gravity = vGravity or h
        // FLAG_LAYOUT_IN_SCREEN makes y count from the very top of the screen on every ROM, so the
        // card starts exactly under the status bar. The glow view keeps `inset` px of transparent
        // margin around the visible card, which is pulled back here so no empty gap is left.
        val insetPx = (ctx.dp(if (settings.glowOn.value) 9f else 6f)).toInt()
        val status = statusBarHeight()
        topInsetBase = status - insetPx
        lp.y = when (vGravity) {
            Gravity.TOP -> topInsetBase + ctx.dpi(topDp) - slackTop
            Gravity.BOTTOM -> ctx.dpi(topDp + 24f) - slackBottom
            else -> 0
        }
        lp.x = if (full || gravityH == 1) 0 else sideX
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        lp.windowAnimations = 0
        try {
            wm.addView(holder, lp)
            if (vGravity == Gravity.TOP && Build.VERSION.SDK_INT >= 30) {
                // Use the real status bar inset reported by the system when it is available.
                holder.setOnApplyWindowInsetsListener { v, ins ->
                    val real = ins.getInsetsIgnoringVisibility(android.view.WindowInsets.Type.statusBars()).top
                    val want = real - insetPx - slackTop + ctx.dpi(topDp)
                    val cur = v.layoutParams as? WindowManager.LayoutParams
                    if (real > 0 && cur != null && cur.y != want) {
                        cur.y = want
                        try { wm.updateViewLayout(v, cur) } catch (_: Exception) {}
                    }
                    ins
                }
                holder.requestApplyInsets()
            }
            root = holder
            card = view
            curVert = when (vGravity) { Gravity.BOTTOM -> 2; Gravity.CENTER_VERTICAL -> 1; else -> 0 }
            currentKey = key
            closing = false
        } catch (_: Exception) {
            root = null
            card = null
            group = null
        }
    }

    /** Puts a new card on top inside the window that is already showing. */
    private fun swapCard(g: FrameLayout, view: View, key: String, vGravity: Int, peeks: List<View>, extra: Int) {
        val old = card
        peekViews.forEach { g.removeView(it) }
        val keepOld = old != null && !promoting && old.parent === g
        if (old != null && !keepOld) {
            PopupAnim.cancelSprings(old)
            g.removeView(old)
        }
        peeks.forEach { g.addView(it) }
        view.alpha = 0f
        g.addView(view, FrameLayout.LayoutParams(-1, -2).apply { bottomMargin = extra })
        if (keepOld && old != null) {
            // The card that was on top tucks back behind the new one.
            old.setOnTouchListener(null)
            PopupAnim.cancelSprings(old)
            val up = vGravity == Gravity.BOTTOM
            old.pivotY = if (up) old.height.toFloat() else 0f
            old.animate().scaleX(0.94f).scaleY(0.94f)
                .translationY(old.translationY + (if (up) -1f else 1f) * ctx.dp(10f))
                .alpha(0f).setDuration(260)
                .withEndAction { g.removeView(old) }.start()
        }
        peekViews = peeks.toMutableList()
        card = view
        currentKey = key
        curVert = when (vGravity) { Gravity.BOTTOM -> 2; Gravity.CENTER_VERTICAL -> 1; else -> 0 }
        closing = false
    }

    /** A buried card was removed: nothing to redraw until the next card change. */
    private fun refreshStackLook() {}

    /** Gives the card room to be pulled down (the handle gesture) without being clipped. */
    internal fun growBottom(on: Boolean) {
        val c = group ?: return
        val clp = c.layoutParams as? FrameLayout.LayoutParams ?: return
        val want = if (on) maxOf(baseSlackBottom, ctx.dpi(120f)) else baseSlackBottom
        if (clp.bottomMargin == want) return
        clp.bottomMargin = want
        c.layoutParams = clp
    }

    internal fun startTimer(bg: GlowBackgroundView?, seconds: Float) {
        timer?.cancel()
        if (seconds <= 0f) return
        timer = ValueAnimator.ofFloat(1f, 0f).apply {
            duration = (seconds * 1000).toLong()
            interpolator = LinearInterpolator()
            addUpdateListener { if (settings.showProgress.value) bg?.progress = it.animatedValue as Float }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                var cancelled = false
                override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(a: android.animation.Animator) { if (!cancelled) dismissAllAnimated() }
            })
            start()
        }
    }

    internal fun haptic() {
        if (!settings.haptic.value) return
        try {
            val vib = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 29) vib.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
            else vib.vibrate(VibrationEffect.createOneShot(12, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {
        }
    }

    internal fun launch(d: PopupData) {
        try {
            d.contentIntent?.send()
        } catch (_: Exception) {
            ctx.packageManager.getLaunchIntentForPackage(d.pkg)?.let {
                it.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(it)
            }
        }
    }

    internal fun flingAway(dx: Float, dirY: Float) {
        val v = card ?: return
        if (closing) return
        closing = true
        timer?.cancel()
        val a = v.animate().alpha(0f).setDuration(200)
        if (dirY == 0f) a.translationX(if (dx > 0) screenW().toFloat() else -screenW().toFloat())
        else a.translationY(dirY * (v.height.toFloat() + 80f))
        a.withEndAction { afterFrontGone() }.start()
    }

    internal fun holdTimer(held: Boolean) {
        if (held) timer?.pause() else timer?.resume()
    }

    internal fun stopTimer() {
        timer?.cancel()
    }

    /** Lets the popup take keyboard focus (needed for the inline reply box). */
    internal fun setFocusable(on: Boolean) {
        val v = root ?: return
        val lp = v.layoutParams as? WindowManager.LayoutParams ?: return
        lp.flags = if (on) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
    }

    internal fun sendReply(a: PopupAction, text: String) {
        val ri = a.remoteInputs ?: return
        try {
            val intent = android.content.Intent().addFlags(android.content.Intent.FLAG_RECEIVER_FOREGROUND)
            val bundle = android.os.Bundle()
            ri.forEach { bundle.putCharSequence(it.resultKey, text) }
            android.app.RemoteInput.addResultsToIntent(ri, intent, bundle)
            a.intent?.send(ctx, 0, intent)
        } catch (_: Exception) {
        }
    }

    internal fun fire(pi: android.app.PendingIntent?) {
        try { pi?.send() } catch (_: Exception) {}
    }

    /** Opens the notification's app in a floating (freeform) window. Falls back to a normal launch. */
    internal fun launchFloating(d: PopupData) {
        if (!freeformReady()) {
            android.widget.Toast.makeText(
                ctx,
                "Floating window off: enable \"Freeform windows\" in Developer options",
                android.widget.Toast.LENGTH_LONG,
            ).show()
        }
        try {
            val dm = ctx.resources.displayMetrics
            val w = (dm.widthPixels * 0.88f).toInt()
            val h = (dm.heightPixels * 0.55f).toInt()
            val l = (dm.widthPixels - w) / 2
            val t = (dm.heightPixels * 0.18f).toInt()
            val opts = android.app.ActivityOptions.makeBasic()
            opts.setLaunchBounds(android.graphics.Rect(l, t, l + w, t + h))
            try {
                // 5 = WINDOWING_MODE_FREEFORM (hidden API, unlocked by HiddenApiBypass).
                android.app.ActivityOptions::class.java
                    .getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType)
                    .invoke(opts, 5)
            } catch (_: Throwable) {
            }
            if (Build.VERSION.SDK_INT >= 34) {
                opts.setPendingIntentBackgroundActivityStartMode(
                    android.app.ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED,
                )
                try {
                    opts.setPendingIntentCreatorBackgroundActivityStartMode(
                        android.app.ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED,
                    )
                } catch (_: Throwable) {}
            }
            val bundle = opts.toBundle()
            // Launch through a fresh intent first: a PendingIntent keeps the app's own task flags
            // and usually forces full screen. The PendingIntent stays as the fallback.
            val i = ctx.packageManager.getLaunchIntentForPackage(d.pkg)
            val pi = d.contentIntent
            if (pi != null) {
                val extra = android.content.Intent().addFlags(
                    android.content.Intent.FLAG_ACTIVITY_NEW_TASK or
                        android.content.Intent.FLAG_ACTIVITY_MULTIPLE_TASK or
                        android.content.Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT,
                )
                pi.send(ctx, 0, extra, null, null, null, bundle)
            } else if (i != null) {
                i.addFlags(
                    android.content.Intent.FLAG_ACTIVITY_NEW_TASK or
                        android.content.Intent.FLAG_ACTIVITY_MULTIPLE_TASK or
                        android.content.Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT,
                )
                ctx.startActivity(i, bundle)
            }
        } catch (_: Exception) {
            launch(d)
        }
    }

    /** The card on top leaves. If notifications are stacked underneath, the next one comes up. */
    internal fun dismissAnimated() {
        val v = card ?: return
        if (closing) return
        if (callShowing || stack.size <= 1) { dismissAllAnimated(); return }
        closing = true
        timer?.cancel()
        val st = settings
        PopupAnim.exit(v, st.entryAnim.value, st.position.value, st.animScale(), screenW(), curVert) { afterFrontGone() }
    }

    /** Everything leaves at once (time is up, or the app was opened). */
    internal fun dismissAllAnimated() {
        val v = card ?: return
        if (closing) return
        closing = true
        timer?.cancel()
        val st = settings
        group?.animate()?.alpha(0f)?.setDuration(230)?.start()
        PopupAnim.exit(v, st.entryAnim.value, st.position.value, st.animScale(), screenW(), curVert) { dismissNow() }
    }

    private fun afterFrontGone() {
        if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex)
        if (callShowing || stack.isEmpty()) {
            dismissNow()
            return
        }
        // Reveal the notification that was underneath.
        closing = false
        promoting = true
        reuse = true
        try {
            showNotification(stack.last())
        } finally {
            promoting = false
        }
    }

    internal fun dismissNow() {
        stack.clear()
        removeCurrent()
    }

    private fun removeCurrent() {
        timer?.cancel()
        timer = null
        card?.let { PopupAnim.cancelSprings(it) }
        root?.let {
            try { wm.removeViewImmediate(it) } catch (_: Exception) {}
        }
        root = null
        card = null
        group = null
        peekViews = mutableListOf()
        currentKey = null
        glow = null
        closing = false
        callShowing = false
        reuse = false
    }

    internal fun screenW(): Int = ctx.resources.displayMetrics.widthPixels

    private fun statusBarHeight(): Int {
        val id = ctx.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else ctx.dpi(24f)
    }

    /** True when the system can show freeform (floating) windows; tries to switch it on if allowed. */
    private fun freeformReady(): Boolean {
        val pm = ctx.packageManager
        if (pm.hasSystemFeature("android.software.freeform_window_management")) return true
        return try {
            val cr = ctx.contentResolver
            if (Settings.Global.getInt(cr, "enable_freeform_support", 0) == 1) return true
            // Works only after: adb shell pm grant com.popupnotify.app android.permission.WRITE_SECURE_SETTINGS
            if (ctx.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                Settings.Global.putInt(cr, "enable_freeform_support", 1)
                Settings.Global.putInt(cr, "force_resizable_activities", 1)
                true
            } else false
        } catch (_: Throwable) { false }
    }

    internal fun text(t: String, sp: Float, color: Int, bold: Boolean): TextView = TextView(ctx).apply {
        text = t
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
}
