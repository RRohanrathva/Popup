package com.popupnotify.app.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.popupnotify.app.SettingsStore

/** Owns the single on-screen popup (notification or call) and everything that animates inside it. */
class OverlayManager(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val settings = SettingsStore.get(ctx)
    private val main = Handler(Looper.getMainLooper())

    private var root: View? = null
    private var currentKey: String? = null
    private var timer: ValueAnimator? = null
    private var glow: GlowBackgroundView? = null
    private var closing = false

    fun canDraw(): Boolean = Settings.canDrawOverlays(ctx)

    fun show(data: PopupData) {
        if (!canDraw()) return
        main.post {
            dismissNow()
            if (data.isCall) showCall(data) else showNotification(data)
        }
    }

    fun dismissKey(key: String) {
        main.post { if (currentKey == key) dismissAnimated() }
    }

    fun destroy() {
        main.post { dismissNow() }
    }

    // ------------------------------------------------------------------ notification card

    private fun showNotification(d: PopupData) {
        val s = settings
        val pal = ctx.popupPalette(s.bgOpacity.value)
        val corner = ctx.dp(s.corner.value)
        val inset = ctx.dp(if (s.glowOn.value) 9f else 7f)

        val card = FrameLayout(ctx)
        val bg = GlowBackgroundView(ctx).apply {
            cornerPx = corner
            this.inset = inset
            fillColor = pal.bg
            glowEnabled = s.glowOn.value
            glowColors = loopColors(s.glowMode.value, pal.accent, s.glowColor.value)
            glowStrokePx = ctx.dp(s.glowWidth.value)
            glowIntensity = s.glowIntensity.value / 100f
            glowSpeed = if (s.animationsOn.value) s.glowSpeed.value * s.animSpeed.value else 0f
            progressColor = pal.accent
            trackColor = pal.track
            progress = if (s.showProgress.value) 1f else -1f
        }
        card.addView(bg, FrameLayout.LayoutParams(-1, -1))
        glow = bg

        val icon = CircleIconView(ctx).apply {
            icon = d.largeIcon ?: d.appIcon
            fallback = ctx.getDrawable(com.popupnotify.app.R.drawable.ic_person)
            discColor = pal.accent
        }
        val badge = CircleIconView(ctx).apply {
            icon = d.appIcon
            discColor = pal.accent
        }
        val iconBox = FrameLayout(ctx).apply {
            addView(icon, FrameLayout.LayoutParams(ctx.dpi(46f), ctx.dpi(46f)))
            if (d.largeIcon != null && d.appIcon != null) {
                addView(
                    badge,
                    FrameLayout.LayoutParams(ctx.dpi(20f), ctx.dpi(20f), Gravity.END or Gravity.BOTTOM),
                )
            }
        }

        val appLine = text(d.appName.uppercase(), 11f, pal.accent, bold = true).apply { letterSpacing = 0.08f }
        val title = text(d.title, 16f, pal.onBg, bold = true)
        val body = text(d.text, 14f, pal.onBgVariant, bold = false).apply { maxLines = 2 }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(appLine)
            if (d.title.isNotBlank()) addView(title)
            if (d.text.isNotBlank()) addView(body)
        }

        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val padH = (inset + ctx.dp(14f)).toInt()
            val padV = (inset + ctx.dp(12f)).toInt()
            setPadding(padH, padV, padH, padV)
            addView(iconBox, LinearLayout.LayoutParams(ctx.dpi(46f), ctx.dpi(46f)).apply {
                marginEnd = ctx.dpi(12f)
            })
            addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        }
        card.addView(row, FrameLayout.LayoutParams(-1, -2))

        card.setOnTouchListener(
            SwipeTouchListener(
                target = card,
                onTap = { launch(d); dismissAnimated() },
                onFling = { dx, up -> flingAway(dx, up) },
                onHold = { held -> if (held) timer?.pause() else timer?.resume() },
            ),
        )

        attach(card, d.key, gravityH = s.position.value, widthPct = s.widthPct.value, topDp = s.topOffset.value, vGravity = Gravity.TOP)
        card.post {
            PopupAnim.enter(card, s.entryAnim.value, s.position.value, s.animScale(), screenW())
            PopupAnim.stagger(listOf(iconBox, col), s.animScale())
            PopupAnim.popIn(iconBox, s.animScale())
            haptic()
            startTimer(bg, s.durationSec.value)
        }
    }

    // ------------------------------------------------------------------ call card

    private fun showCall(d: PopupData) {
        CallPopup(ctx, settings, this).build(d)
    }

    // ------------------------------------------------------------------ shared plumbing

    internal fun attach(
        view: View,
        key: String,
        gravityH: Int,
        widthPct: Float,
        topDp: Float,
        vGravity: Int,
    ) {
        val w = (screenW() * widthPct.coerceIn(60f, 100f) / 100f).toInt()
        val lp = WindowManager.LayoutParams(
            w,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT,
        )
        val h = when (gravityH) {
            0 -> Gravity.START
            2 -> Gravity.END
            else -> Gravity.CENTER_HORIZONTAL
        }
        lp.gravity = vGravity or h
        val status = statusBarHeight()
        lp.y = if (vGravity == Gravity.TOP) (status + ctx.dp(topDp)).toInt() else if (vGravity == Gravity.BOTTOM) ctx.dpi(topDp + 12f) else 0
        lp.x = if (gravityH == 1) 0 else ctx.dpi(((100f - widthPct.coerceIn(60f, 100f)) / 2f).coerceAtMost(4f))
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        lp.windowAnimations = 0
        try {
            wm.addView(view, lp)
            root = view
            currentKey = key
            closing = false
        } catch (_: Exception) {
            root = null
        }
    }

    internal fun startTimer(bg: GlowBackgroundView?, seconds: Float) {
        timer?.cancel()
        if (seconds <= 0f) return
        timer = ValueAnimator.ofFloat(1f, 0f).apply {
            duration = (seconds * 1000).toLong()
            interpolator = LinearInterpolator()
            addUpdateListener { if (settings.showProgress.value) bg?.progress = it.animatedValue as Float }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                var cancelled = false
                override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(a: android.animation.Animator) { if (!cancelled) dismissAnimated() }
            })
            start()
        }
    }

    internal fun haptic() {
        if (!settings.haptic.value) return
        try {
            val vib = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 29) vib.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
            else vib.vibrate(VibrationEffect.createOneShot(12, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {
        }
    }

    internal fun launch(d: PopupData) {
        try {
            d.contentIntent?.send()
        } catch (_: Exception) {
            ctx.packageManager.getLaunchIntentForPackage(d.pkg)?.let {
                it.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(it)
            }
        }
    }

    private fun flingAway(dx: Float, up: Boolean) {
        val v = root ?: return
        timer?.cancel()
        val target = if (up) null else if (dx > 0) screenW().toFloat() else -screenW().toFloat()
        val a = v.animate().alpha(0f).setDuration(200)
        if (target != null) a.translationX(target) else a.translationY(-v.height.toFloat() - 60f)
        a.withEndAction { dismissNow() }.start()
    }

    internal fun dismissAnimated() {
        val v = root ?: return
        if (closing) return
        closing = true
        timer?.cancel()
        val st = settings
        PopupAnim.exit(v, st.entryAnim.value, st.position.value, st.animScale(), screenW()) { dismissNow() }
    }

    internal fun dismissNow() {
        timer?.cancel()
        timer = null
        root?.let {
            PopupAnim.cancelSprings(it)
            try { wm.removeViewImmediate(it) } catch (_: Exception) {}
        }
        root = null
        currentKey = null
        glow = null
        closing = false
    }

    internal fun screenW(): Int = ctx.resources.displayMetrics.widthPixels

    private fun statusBarHeight(): Int {
        val id = ctx.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else ctx.dpi(24f)
    }

    internal fun text(t: String, sp: Float, color: Int, bold: Boolean): TextView = TextView(ctx).apply {
        text = t
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
}
