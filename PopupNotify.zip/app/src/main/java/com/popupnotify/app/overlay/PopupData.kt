package com.popupnotify.app.overlay

import android.app.PendingIntent
import android.graphics.drawable.Drawable

data class PopupData(
    val key: String,
    val pkg: String,
    val appName: String,
    val title: String,
    val text: String,
    val appIcon: Drawable?,
    val largeIcon: Drawable?,
    val contentIntent: PendingIntent?,
    val isCall: Boolean,
    val answer: PendingIntent?,
    val decline: PendingIntent?,
)
