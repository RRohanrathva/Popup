package com.popupnotify.app.service

import android.app.Notification
import android.graphics.drawable.Drawable
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.popupnotify.app.SettingsStore
import com.popupnotify.app.overlay.OverlayManager
import com.popupnotify.app.overlay.PopupData

class PopupListenerService : NotificationListenerService() {

    private lateinit var overlay: OverlayManager
    private lateinit var settings: SettingsStore

    override fun onCreate() {
        super.onCreate()
        overlay = OverlayManager(applicationContext)
        settings = SettingsStore.get(applicationContext)
    }

    override fun onDestroy() {
        overlay.destroy()
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!settings.popupEnabled.value) return
        if (sbn.packageName == packageName) return
        if (sbn.packageName in settings.blocked) return

        val n = sbn.notification
        val flags = n.flags
        if (flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (flags and Notification.FLAG_FOREGROUND_SERVICE != 0) return
        if (settings.ignoreOngoing.value && flags and Notification.FLAG_ONGOING_EVENT != 0 &&
            n.category != Notification.CATEGORY_CALL
        ) return

        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val isCall = n.category == Notification.CATEGORY_CALL && n.fullScreenIntent != null ||
            (n.category == Notification.CATEGORY_CALL && isIncomingCall(n))
        if (isCall && !settings.callEnabled.value) return

        val appIcon: Drawable? = try { packageManager.getApplicationIcon(sbn.packageName) } catch (_: Exception) { null }
        val appName = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) { sbn.packageName }
        val large: Drawable? = try { n.getLargeIcon()?.loadDrawable(this) } catch (_: Exception) { null }

        var answer: android.app.PendingIntent? = null
        var decline: android.app.PendingIntent? = null
        if (isCall) {
            n.actions?.forEach { a ->
                val t = a.title?.toString()?.lowercase().orEmpty()
                if (answer == null && (t.contains("answer") || t.contains("accept") || t.contains("pick") || t.contains("उत्तर"))) answer = a.actionIntent
                if (decline == null && (t.contains("decline") || t.contains("reject") || t.contains("hang") || t.contains("end") || t.contains("dismiss"))) decline = a.actionIntent
            }
            if (answer == null && n.actions?.size == 2) {
                decline = n.actions[0].actionIntent
                answer = n.actions[1].actionIntent
            }
        }

        overlay.show(
            PopupData(
                key = sbn.key,
                pkg = sbn.packageName,
                appName = appName,
                title = title,
                text = text,
                appIcon = appIcon,
                largeIcon = large,
                contentIntent = n.contentIntent,
                isCall = isCall,
                answer = answer,
                decline = decline,
            ),
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        overlay.dismissKey(sbn.key)
    }

    private fun isIncomingCall(n: Notification): Boolean = (n.actions?.size ?: 0) >= 2
}
