@file:OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class)

package com.popupnotify.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import com.popupnotify.app.overlay.OverlayManager
import com.popupnotify.app.ui.AppsScreen
import com.popupnotify.app.ui.CallScreen
import com.popupnotify.app.ui.HomeScreen
import com.popupnotify.app.ui.PopupScreen

class MainActivity : ComponentActivity() {

    private val refresh = mutableIntStateOf(0)
    private lateinit var overlay: OverlayManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        overlay = OverlayManager(applicationContext)
        val settings = SettingsStore.get(applicationContext)

        setContent {
            AppTheme {
                var tab by rememberSaveable { mutableIntStateOf(0) }
                val titles = listOf("Popup Notify", "Popup style", "Call popup", "Apps")
                val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()

                Scaffold(
                    modifier = Modifier.fillMaxSize().nestedScroll(scroll.nestedScrollConnection),
                    containerColor = MaterialTheme.colorScheme.surface,
                    topBar = {
                        LargeTopAppBar(
                            title = { Text(titles[tab], fontWeight = FontWeight.Bold) },
                            scrollBehavior = scroll,
                        )
                    },
                    bottomBar = {
                        NavigationBar {
                            val items = listOf(
                                Icons.Filled.Home to "Home",
                                Icons.Filled.Notifications to "Popup",
                                Icons.Filled.Call to "Call",
                                Icons.Filled.List to "Apps",
                            )
                            items.forEachIndexed { i, (icon, label) ->
                                NavigationBarItem(
                                    selected = tab == i,
                                    onClick = { tab = i },
                                    icon = { Icon(icon, null) },
                                    label = { Text(label) },
                                )
                            }
                        }
                    },
                ) { inner ->
                    AnimatedContent(
                        targetState = tab,
                        modifier = Modifier.padding(inner),
                        transitionSpec = {
                            (fadeIn(spring(stiffness = Spring.StiffnessMediumLow)) +
                                scaleIn(initialScale = 0.92f, animationSpec = spring(0.7f, Spring.StiffnessMediumLow)) +
                                slideInVertically(spring(0.8f, Spring.StiffnessMediumLow)) { it / 14 })
                                .togetherWith(fadeOut(spring(stiffness = Spring.StiffnessMedium)) + scaleOut(targetScale = 0.96f))
                        },
                        label = "tabs",
                    ) { t ->
                        Surface(color = MaterialTheme.colorScheme.surface) {
                            when (t) {
                                0 -> HomeScreen(settings, overlay, refresh.intValue)
                                1 -> PopupScreen(settings, overlay)
                                2 -> CallScreen(settings, overlay)
                                else -> AppsScreen(settings)
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh.intValue++
    }

    override fun onDestroy() {
        overlay.destroy()
        super.onDestroy()
    }
}

@Composable
private fun AppTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val scheme = when {
        android.os.Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialExpressiveTheme(
        colorScheme = scheme,
        motionScheme = MotionScheme.expressive(),
        content = content,
    )
}
