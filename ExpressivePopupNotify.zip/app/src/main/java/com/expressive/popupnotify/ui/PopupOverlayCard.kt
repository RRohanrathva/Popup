package com.expressive.popupnotify.ui

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class PopupOrigin { TOP_LEFT, TOP_CENTER, TOP_RIGHT }

data class PopupConfig(
    val durationSec: Float = 4.5f,
    val cornerRadiusDp: Float = 28f,
    val glowEnabled: Boolean = true,
    val origin: PopupOrigin = PopupOrigin.TOP_CENTER,
    val isCallPopup: Boolean = false,
    val callAccentColor: Color = Color(0xFF34C759)
)

@Composable
fun PopupOverlayCard(
    context: Context,
    appName: String,
    title: String,
    message: String,
    config: PopupConfig,
    contentIntent: PendingIntent?,
    targetPackage: String?,
    onDismiss: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "glowAnim")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = if (config.glowEnabled) 0.25f else 0f,
        targetValue = if (config.glowEnabled) 0.85f else 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    var dragOffsetY by remember { mutableFloatStateOf(0f) }

    val horizontalAlignment = when (config.origin) {
        PopupOrigin.TOP_LEFT -> Alignment.Start
        PopupOrigin.TOP_CENTER -> Alignment.CenterHorizontally
        PopupOrigin.TOP_RIGHT -> Alignment.End
    }

    val shape = RoundedCornerShape(config.cornerRadiusDp.dp)
    val activeColor = if (config.isCallPopup) config.callAccentColor else MaterialTheme.colorScheme.primary

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = when (config.origin) {
            PopupOrigin.TOP_LEFT -> Alignment.TopStart
            PopupOrigin.TOP_CENTER -> Alignment.TopCenter
            PopupOrigin.TOP_RIGHT -> Alignment.TopEnd
        }
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(if (config.origin == PopupOrigin.TOP_CENTER) 1f else 0.92f)
                .shadow(
                    elevation = if (config.glowEnabled) 16.dp else 8.dp,
                    shape = shape,
                    ambientColor = activeColor.copy(alpha = glowAlpha),
                    spotColor = activeColor.copy(alpha = glowAlpha)
                )
                .clip(shape)
                .clickable {
                    try {
                        contentIntent?.send()
                    } catch (_: Exception) { }
                    onDismiss()
                },
            shape = shape,
            color = if (config.isCallPopup)
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.96f)
            else
                MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.96f),
            border = BorderStroke(
                width = if (config.glowEnabled) 2.dp else 1.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        activeColor.copy(alpha = glowAlpha.coerceAtLeast(0.25f)),
                        MaterialTheme.colorScheme.secondary.copy(alpha = glowAlpha.coerceAtLeast(0.2f))
                    )
                )
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalAlignment = horizontalAlignment
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(if (config.isCallPopup) 38.dp else 32.dp)
                                .clip(CircleShape)
                                .background(activeColor.copy(alpha = 0.22f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (config.isCallPopup) "📞" else appName.take(1).uppercase(),
                                fontWeight = FontWeight.Bold,
                                color = activeColor
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (config.isCallPopup) "INCOMING CALL • $appName" else appName,
                                style = MaterialTheme.typography.labelMedium,
                                color = activeColor,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(22.dp)
                        .pointerInput(targetPackage) {
                            detectVerticalDragGestures(
                                onDragEnd = {
                                    if (dragOffsetY > 36f) {
                                        launchInFloatingWindow(context, targetPackage, contentIntent)
                                        onDismiss()
                                    }
                                    dragOffsetY = 0f
                                },
                                onVerticalDrag = { _, dragAmount ->
                                    dragOffsetY += dragAmount
                                }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .width(44.dp)
                                .height(4.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f))
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Swipe down for Floating Window",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

private fun launchInFloatingWindow(
    context: Context,
    packageName: String?,
    contentIntent: PendingIntent?
) {
    try {
        if (packageName != null) {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)?.apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_MULTIPLE_TASK or
                        Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT
                )
            }
            if (launchIntent != null) {
                context.startActivity(launchIntent)
                return
            }
        }
        contentIntent?.send()
    } catch (_: Exception) { }
}
