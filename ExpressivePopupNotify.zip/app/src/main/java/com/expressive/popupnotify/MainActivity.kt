package com.expressive.popupnotify

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.expressive.popupnotify.ui.ExpressivePopupTheme
import com.expressive.popupnotify.ui.PopupConfig
import com.expressive.popupnotify.ui.SettingsScreen

class MainActivity : ComponentActivity() {

    companion object {
        var currentConfig by mutableStateOf(PopupConfig())
        var callPopupEnabled by mutableStateOf(true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestPermissions(
            arrayOf(
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.POST_NOTIFICATIONS
            ),
            101
        )

        setContent {
            ExpressivePopupTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    SettingsScreen(
                        config = currentConfig,
                        callPopupEnabled = callPopupEnabled,
                        onConfigChange = { currentConfig = it },
                        onCallPopupToggle = { callPopupEnabled = it },
                        onRequestPermissions = {
                            if (!Settings.canDrawOverlays(this)) {
                                startActivity(
                                    Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:$packageName")
                                    )
                                )
                            } else {
                                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                            }
                        },
                        onTestNotificationPopup = {
                            OverlayManager.showPopup(
                                context = this,
                                appName = "WhatsApp",
                                title = "Expressive Popup Ready",
                                message = "Swipe down the bottom bar to open in HyperOS Floating Window!",
                                config = currentConfig.copy(isCallPopup = false),
                                targetPackage = "com.whatsapp"
                            )
                        },
                        onTestCallPopup = {
                            OverlayManager.showPopup(
                                context = this,
                                appName = "Phone",
                                title = "+91 98765 43210",
                                message = "Incoming Call • Expressive Call Popup",
                                config = currentConfig.copy(isCallPopup = true),
                                targetPackage = "com.android.incallui"
                            )
                        }
                    )
                }
            }
        }
    }
}
