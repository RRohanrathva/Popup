package com.expressive.popupnotify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

class CallOverlayService : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!MainActivity.callPopupEnabled) return
        if (intent.action == TelephonyManager.ACTION_PHONE_STATE_CHANGED) {
            val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
            if (state == TelephonyManager.EXTRA_STATE_RINGING) {
                val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: "Incoming Call"
                OverlayManager.showPopup(
                    context = context.applicationContext,
                    appName = "Phone",
                    title = incomingNumber,
                    message = "Swipe down bottom bar for Floating Window",
                    config = MainActivity.currentConfig.copy(isCallPopup = true, durationSec = 10f),
                    targetPackage = "com.android.incallui"
                )
            }
        }
    }
}
