package com.expressive.popupnotify.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(
    config: PopupConfig,
    callPopupEnabled: Boolean,
    onConfigChange: (PopupConfig) -> Unit,
    onCallPopupToggle: (Boolean) -> Unit,
    onRequestPermissions: () -> Unit,
    onTestNotificationPopup: () -> Unit,
    onTestCallPopup: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Expressive Popup",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.ExtraBold
        )
        Text(
            text = "Android 17 Material 3 style floating popups for Redmi Note 14 5G",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Card(
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Permissions & Setup", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "1. Enable Display Over Other Apps (Overlay)\n2. Enable Notification Listener Access\n3. Enable Phone State for Call Popups",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(onClick = onRequestPermissions, modifier = Modifier.fillMaxWidth()) {
                    Text("Grant Required Permissions")
                }
            }
        }

        Card(
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Popup Duration: ${"%.1f".format(config.durationSec)}s", fontWeight = FontWeight.SemiBold)
                Slider(
                    value = config.durationSec,
                    onValueChange = { onConfigChange(config.copy(durationSec = it)) },
                    valueRange = 1.5f..12f
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text("Border Roundness: ${config.cornerRadiusDp.toInt()} dp", fontWeight = FontWeight.SemiBold)
                Slider(
                    value = config.cornerRadiusDp,
                    onValueChange = { onConfigChange(config.copy(cornerRadiusDp = it)) },
                    valueRange = 8f..40f
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Glow Animation", fontWeight = FontWeight.SemiBold)
                    Switch(
                        checked = config.glowEnabled,
                        onCheckedChange = { onConfigChange(config.copy(glowEnabled = it)) }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text("Top Screen Origin", fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PopupOrigin.entries.forEach { origin ->
                        FilterChip(
                            selected = config.origin == origin,
                            onClick = { onConfigChange(config.copy(origin = origin)) },
                            label = {
                                Text(
                                    when (origin) {
                                        PopupOrigin.TOP_LEFT -> "Top Left"
                                        PopupOrigin.TOP_CENTER -> "Top Center"
                                        PopupOrigin.TOP_RIGHT -> "Top Right"
                                    }
                                )
                            }
                        )
                    }
                }
            }
        }

        Card(
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Separate Call Popup", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Switch(checked = callPopupEnabled, onCheckedChange = onCallPopupToggle)
                }
                Text(
                    "Shows a dedicated Expressive call banner distinct from standard app notifications.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onTestNotificationPopup, modifier = Modifier.weight(1f)) {
                Text("Test App Popup")
            }
            Button(onClick = onTestCallPopup, modifier = Modifier.weight(1f)) {
                Text("Test Call Popup")
            }
        }
    }
}
